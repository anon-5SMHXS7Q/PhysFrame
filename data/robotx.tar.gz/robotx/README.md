# RIP RobotX Repository
This repository is defunct, but remains for archival purposes.  Please see our new Github [at this link](https://github.com/riplaboratory/Kanaloa).

You may also visit our the [RIP Laboratory website at this link](rip.eng.hawaii.edu)

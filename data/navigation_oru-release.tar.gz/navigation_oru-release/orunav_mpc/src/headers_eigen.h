#pragma once

// disable some of the warnings

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshadow"

#include <Eigen/Core>
#include <Eigen/Geometry>

#pragma GCC diagnostic pop

#include <orunav_msgs/RobotTarget.h>

int main()
{
  orunav_msgs::RobotTarget t;
  return 1;
}

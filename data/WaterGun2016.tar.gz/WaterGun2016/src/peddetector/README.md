Pedestrian Detector
===================

This project is a port of Piotr Dollar's Image & Video Matlab Toolbox found [here](https://github.com/pdollar/toolbox/ "Piotr Dollar's Matlab Toolbox").

If you need more information please feel free to contact me.
Bare in mind that this may be outdated regarding Piotr Dollar's work.

Requirements:
* OpenCV
* CMake

Work made for [IST - Técnico Lisboa](http://tecnico.ulisboa.pt/en/ "Técnico Lisboa")

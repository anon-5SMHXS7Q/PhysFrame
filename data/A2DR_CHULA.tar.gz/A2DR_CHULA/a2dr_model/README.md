# a2dr_model
Collect sensors for robots. [URDF, XACRO, GAZEBO]

## Sensors

* [ ] Intel realsense D435
* [x] IMU MPU9250
* [x] Lidar YDLidar G4

## Actuators

* [ ] Brushless DC Motor Hoverboard 6.5"

NOTES
======
Author: Luke Fraser

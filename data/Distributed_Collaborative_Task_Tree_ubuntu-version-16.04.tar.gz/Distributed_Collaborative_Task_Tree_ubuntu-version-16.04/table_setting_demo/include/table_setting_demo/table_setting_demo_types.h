#ifndef TABLE_SETTING_DEMO_TYPES_H_
#define TABLE_SETTING_DEMO_TYPES_H_
#include <std_msgs/Float32MultiArray.h>
namespace table_setting_demo {
// Define types for use within the tables setting demo
class pick_and_place;

typedef pick_and_place qr_inview;
}
#endif  // TABLE_SETTING_DEMO_TYPES_H_
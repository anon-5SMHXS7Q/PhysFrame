Object Manipulation Applications/Libraries
==========================================

Author: Luke Fraser

=== Summary ===

This project is reposponsible for the manipulation of objects in real time on the PR2 and Baxter robot platforms. The interfeace betwen each robot is identical and produces similar behavior.

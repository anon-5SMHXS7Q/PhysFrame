# Racecar Platform

 This is a heavily modified version of MIT's Racecar Self Driving Vehicle used for Autonomous Vehicle Research at Georgia Tech.

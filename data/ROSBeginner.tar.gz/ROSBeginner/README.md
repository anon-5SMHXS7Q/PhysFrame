# ROSBeginner
Starter assignments 
# Project TFframes
To run the project:
1. start roscore
2. rosrun project2_solution solution.py
3. rosrun rviz rviz (change fixed_frame to base_frame and add TF and marker library in rviz)
4. rosrun marker_publisher marker_publisher

# Mobile robot simulation 
1. roslaunch mobilerobot_rviz.launch model:=mobilerobot.urdf to run the base link 

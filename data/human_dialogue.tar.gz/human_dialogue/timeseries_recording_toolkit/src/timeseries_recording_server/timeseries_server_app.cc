#include "log.h"

// Please Handle Command Line arguments
int main(int argc, char *argv[]) {
  return 0;
}

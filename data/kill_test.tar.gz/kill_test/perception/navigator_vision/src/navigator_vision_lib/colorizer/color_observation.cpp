#include <colorizer/color_observation.hpp>


namespace nav{

UnoccludedPointsImg::UnoccludedPointsImg()
// : frame_ptr(frame_ptr),
//   cloud_ptr(cloud_ptr)  
{
  // auto cam_model = frame_ptr->getCameraModelPtr();


}

} // namespace nav
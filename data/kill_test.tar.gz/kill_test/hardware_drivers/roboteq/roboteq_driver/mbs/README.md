This directory contains a MicroBasic source file. To compile this file to the
bytecode understood by a Roboteq controller, first download RoboRun+ from the
following location:

http://www.roboteq.com/index.php/support/downloads

Install and run the utility, go to the scripts tab, and load the file. Click
Export HEX, and save the resultant file into this directory.

#include "gui.h"

GUI::GUI(QWidget *parent)
    : QMainWindow(parent)
{
}

GUI::~GUI()
{

}

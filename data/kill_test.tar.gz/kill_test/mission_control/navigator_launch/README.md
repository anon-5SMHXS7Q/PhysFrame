To launch the lqRRT node run the install script to download it 
1. Go to the lqRRT node in your catkin workspace

run: 
'python setup.py build
sudo python setup.py install'

Then run catkin_make
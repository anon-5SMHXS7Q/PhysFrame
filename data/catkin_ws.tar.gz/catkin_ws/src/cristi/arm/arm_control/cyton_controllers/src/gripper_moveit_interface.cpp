#include "ros/ros.h"
#include "std_msgs/String.h"
#include "control_msgs/GripperCommandAction.h"

#include <sstream>
#include <actionlib/server/simple_action_server.h>

class GripperCommandAction {
protected:
	ros::NodeHandle node_handle;
	actionlib::SimpleActionServer action_server;
	std::string action_name;
	control_msgs::GripperCommandActionFeedback feedback;
	control_msgs::GripperCommandActionResult result;

public:

	GripperCommandAction(std::string name) :
			action_server(node_handle, name,
					boost::bind(&GripperCommandAction::executeCB, this, _1),
					false), action_name(name) {
		action_server.start();
	}

};

int main(int argc, char **argv) {
	ros::init(argc, argv, "gripper_moveit_interface");

	ros::NodeHandle n;

//ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);

	ros::Rate loop_rate(10);

	actionlib::SimpleActionServer action_server;

	/**
	 * A count of how many messages we have sent. This is used to create
	 * a unique string for each message.
	 */
	int count = 0;
	while (ros::ok()) {
		/**
		 * This is a message object. You stuff it with data, and then publish it.
		 */
		std_msgs::String msg;

		std::stringstream ss;
		ss << "hello world " << count;
		msg.data = ss.str();

		ROS_INFO("%s", msg.data.c_str());

		/**
		 * The publish() function is how you send messages. The parameter
		 * is the message object. The type of this object must agree with the type
		 * given as a template parameter to the advertise<>() call, as was done
		 * in the constructor above.
		 */
		chatter_pub.publish(msg);

		ros::spinOnce();

		loop_rate.sleep();
		++count;
	}

	return 0;
}

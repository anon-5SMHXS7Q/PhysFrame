#ifndef COMMON_H_
#define COMMON_H_

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

typedef pcl::PointXYZRGB PointType;

#endif

#include "color_detector.hpp"

Bottle ColorDetector::detect(pcl::PointCloud<PointType>::Ptr cloud) {
    return Bottle();
}

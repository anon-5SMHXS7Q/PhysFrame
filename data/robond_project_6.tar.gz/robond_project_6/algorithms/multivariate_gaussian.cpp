#include <iostream>
#include <math.h>
#include <tuple>

using namespace std;

int main(int argc, char const *argv[]) {
    
    
  


    return 0;
元のファイルの場所
https://github.com/raucha/chairbot_selfdrive

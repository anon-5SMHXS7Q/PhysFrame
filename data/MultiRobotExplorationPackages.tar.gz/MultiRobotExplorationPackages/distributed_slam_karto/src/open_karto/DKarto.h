#ifndef DKARTO_H
#define DKARTO_H

namespace karto{
    // distibuted laser range finder data
    
}

#endif
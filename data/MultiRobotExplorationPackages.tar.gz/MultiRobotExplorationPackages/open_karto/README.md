# Open Karto

Catkinized ROS Package of the OpenKarto Library (LGPL3)

# Status

 * Devel Job Status: [![Build Status](http://build.ros.org/buildStatus/icon?job=Idev__open_karto__ubuntu_trusty_amd64)](http://build.ros.org/job/Idev__open_karto__ubuntu_trusty_amd64/)
 * AMD64 Debian Job Status: [![Build Status](http://build.ros.org/buildStatus/icon?job=Jbin_uT64__open_karto__ubuntu_trusty_amd64__binary)](http://build.ros.org/job/Jbin_uT64__open_karto__ubuntu_trusty_amd64__binary)

Sparse Bundle Adjustment Library
================================

Originally developed at Willow Garage as part of the vslam stack.

ME495 FINAL PROJECT: Embedded Systems in Robotics
==============
##### Group 6: Nate, Brianna, Chainatee, Jiarui


## Introduction

## Add More Sections

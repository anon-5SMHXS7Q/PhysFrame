## About

This packages provide path planning for moving the quadrotor in 3D using ROS.

## License

Copyright (c) 2012-2013, Daiki Maekawa. (BSD License)

See LICENSE for more info.

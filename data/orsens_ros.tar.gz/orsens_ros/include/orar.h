#ifndef ORAR_H_INCLUDED
#define ORAR_H_INCLUDED

#include "aruco/aruco.h"
#include "aruco/cvdrawingutils.h"

using namespace aruco;

#endif // ORAR_H_INCLUDED

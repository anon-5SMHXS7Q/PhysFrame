# orsens_ros
[![Build Status](https://travis-ci.org/Oriense/orsens_ros.svg?branch=master)](https://travis-ci.org/Oriense/orsens_ros)

ROS package for OrSens 3d-camera.

For documentation please visit the [orsens_ros](http://wiki.ros.org/orsens_ros) page on the ROS wiki or the [API documentation](http://docs.ros.org/indigo/api/orsens/html/c++/orsens_8h.html)

memo
1. arduino ide
2. autoware
3. wifi
4. jetson tx1 setup
5. realsense
6. imu inclusing imu plugin for rviz
7. structure sensor
8. zed setup on tx1
9. network setup
10.BLDC(VESC) setup

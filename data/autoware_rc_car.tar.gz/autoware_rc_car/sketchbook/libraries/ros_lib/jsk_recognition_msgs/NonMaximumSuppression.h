#ifndef _ROS_SERVICE_NonMaximumSuppression_h
#define _ROS_SERVICE_NonMaximumSuppression_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "jsk_recognition_msgs/Rect.h"

namespace jsk_recognition_msgs
{

static const char NONMAXIMUMSUPPRESSION[] = "jsk_recognition_msgs/NonMaximumSuppression";

  class NonMaximumSuppressionRequest : public ros::Msg
  {
    public:
      uint8_t rect_length;
      jsk_recognition_msgs::Rect st_rect;
      jsk_recognition_msgs::Rect * rect;
      float threshold;

    NonMaximumSuppressionRequest():
      rect_length(0), rect(NULL),
      threshold(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset++) = rect_length;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      for( uint8_t i = 0; i < rect_length; i++){
      offset += this->rect[i].serialize(outbuffer + offset);
      }
      union {
        float real;
        uint32_t base;
      } u_threshold;
      u_threshold.real = this->threshold;
      *(outbuffer + offset + 0) = (u_threshold.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_threshold.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_threshold.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_threshold.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->threshold);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint8_t rect_lengthT = *(inbuffer + offset++);
      if(rect_lengthT > rect_length)
        this->rect = (jsk_recognition_msgs::Rect*)realloc(this->rect, rect_lengthT * sizeof(jsk_recognition_msgs::Rect));
      offset += 3;
      rect_length = rect_lengthT;
      for( uint8_t i = 0; i < rect_length; i++){
      offset += this->st_rect.deserialize(inbuffer + offset);
        memcpy( &(this->rect[i]), &(this->st_rect), sizeof(jsk_recognition_msgs::Rect));
      }
      union {
        float real;
        uint32_t base;
      } u_threshold;
      u_threshold.base = 0;
      u_threshold.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_threshold.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_threshold.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_threshold.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->threshold = u_threshold.real;
      offset += sizeof(this->threshold);
     return offset;
    }

    const char * getType(){ return NONMAXIMUMSUPPRESSION; };
    const char * getMD5(){ return "54b7e6632715e9e6592b503a3c881dfc"; };

  };

  class NonMaximumSuppressionResponse : public ros::Msg
  {
    public:
      uint8_t bbox_length;
      jsk_recognition_msgs::Rect st_bbox;
      jsk_recognition_msgs::Rect * bbox;
      int64_t bbox_count;

    NonMaximumSuppressionResponse():
      bbox_length(0), bbox(NULL),
      bbox_count(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset++) = bbox_length;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      for( uint8_t i = 0; i < bbox_length; i++){
      offset += this->bbox[i].serialize(outbuffer + offset);
      }
      union {
        int64_t real;
        uint64_t base;
      } u_bbox_count;
      u_bbox_count.real = this->bbox_count;
      *(outbuffer + offset + 0) = (u_bbox_count.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_bbox_count.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_bbox_count.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_bbox_count.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_bbox_count.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_bbox_count.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_bbox_count.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_bbox_count.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->bbox_count);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint8_t bbox_lengthT = *(inbuffer + offset++);
      if(bbox_lengthT > bbox_length)
        this->bbox = (jsk_recognition_msgs::Rect*)realloc(this->bbox, bbox_lengthT * sizeof(jsk_recognition_msgs::Rect));
      offset += 3;
      bbox_length = bbox_lengthT;
      for( uint8_t i = 0; i < bbox_length; i++){
      offset += this->st_bbox.deserialize(inbuffer + offset);
        memcpy( &(this->bbox[i]), &(this->st_bbox), sizeof(jsk_recognition_msgs::Rect));
      }
      union {
        int64_t real;
        uint64_t base;
      } u_bbox_count;
      u_bbox_count.base = 0;
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_bbox_count.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->bbox_count = u_bbox_count.real;
      offset += sizeof(this->bbox_count);
     return offset;
    }

    const char * getType(){ return NONMAXIMUMSUPPRESSION; };
    const char * getMD5(){ return "8db21435e67f6d13fc94ccbd355f30f1"; };

  };

  class NonMaximumSuppression {
    public:
    typedef NonMaximumSuppressionRequest Request;
    typedef NonMaximumSuppressionResponse Response;
  };

}
#endif

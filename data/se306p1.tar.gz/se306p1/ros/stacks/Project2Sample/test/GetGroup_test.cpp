/*
 * Example_test.cpp
 *
 *  Created on: 17/08/2012
 *      Author: Brett
 */
#include <gtest/gtest.h>
#include <ros/ros.h>
#include "../src/GetGroup.h"

TEST(Example_tests, test1) {
	// Assert stuff here
}

TEST(Example_tests, test2) {

}

int main(int argc, char **argv) {
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

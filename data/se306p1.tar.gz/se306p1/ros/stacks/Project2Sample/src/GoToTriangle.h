/*
 * GoToTriangle.h
 *
 *  Created on: Aug 23, 2012
 *      Author: charu
 */

#ifndef GOTOTRIANGLE_H_
#define GOTOTRIANGLE_H_
#include "Project2Sample/R_ID.h"

using namespace std;

	vector<float> formTriangle(Project2Sample::R_ID inputs, int groupsize);


#endif /* GOTOTRIANGLE_H_ */

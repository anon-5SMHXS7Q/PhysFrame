/*
 * GoToCircle.h
 *
 *  Created on: Aug 15, 2012
 *      Author: charu
 */

#ifndef GOTOCIRCLE_H_
#define GOTOCIRCLE_H_
#include "Project2Sample/R_ID.h"

using namespace std;

	vector<float> formCircle(Project2Sample::R_ID inputs, int groupsize);


#endif /* GOTOCIRCLE_H_ */

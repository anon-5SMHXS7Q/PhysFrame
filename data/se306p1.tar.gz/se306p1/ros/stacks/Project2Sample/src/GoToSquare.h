/*
 * GoToSquare.h
 *
 *  Created on: Aug 15, 2012
 *      Author: charu
 */

#ifndef GOTOSQUARE_H_
#define GOTOSQUARE_H_
#include "Project2Sample/R_ID.h"

using namespace std;

	vector<float> formSquare(Project2Sample::R_ID inputs, int groupsize);


#endif /* GOTOSQUARE_H_ */

# ROS Workspace

[WIP]

[Image Detection](./src/image_detection)

[KITTI Detection](./src/kitti_detection)

[LINKE Detection](./src/linke_detection)

```
git clone --recursive https://github.com/yusanshi/ros_package
cd ros_package
chmod +x utils/apply_patches.sh
./utils/apply_patches.sh
```
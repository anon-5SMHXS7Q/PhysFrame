iai_control_pkgs
================

Collection of various robot control packages, written/maintained by the iai group at Universitaet Bremen.

iai_common_msgs
===============

Holds various ROS message definitions used by the IAI group, Universität Bremen.
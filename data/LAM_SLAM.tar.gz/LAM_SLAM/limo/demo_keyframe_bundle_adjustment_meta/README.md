# demo keyframe bundle adjustment meta

This is a demo package with launch files for keyframe bundle adjustment with kitti

* mrtmount
* launch kitti_standalone

## Credits

Johannes Gräter
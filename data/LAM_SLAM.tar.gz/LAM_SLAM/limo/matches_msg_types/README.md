# Matches Msg Types

Non ros types for matches msgs for use in libraries

## Credits

Johannes Gräter
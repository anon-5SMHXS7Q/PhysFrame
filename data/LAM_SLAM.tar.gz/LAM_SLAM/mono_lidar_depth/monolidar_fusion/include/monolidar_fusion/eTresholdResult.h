/*
 * eTresholdResult.h
 *
 *  Created on: Mar 17, 2017
 *      Author: wilczynski
 */

#pragma once

namespace Mono_Lidar {
enum eTresholdResult { InBounds, SmallerMin, GreaterMax };
}

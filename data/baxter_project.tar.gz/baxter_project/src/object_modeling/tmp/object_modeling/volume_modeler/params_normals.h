#pragma once

struct ParamsNormals
{
	float max_depth_sigmas;
	int smooth_iterations;

	ParamsNormals()
		: max_depth_sigmas(3), // should try higher, maybe
		smooth_iterations(2)
	{}
};
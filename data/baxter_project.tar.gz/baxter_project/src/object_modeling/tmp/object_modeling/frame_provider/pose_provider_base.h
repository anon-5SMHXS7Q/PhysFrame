#pragma once

#include "EigenUtilities.h"

class PoseProviderBase
{
public:
    PoseProviderBase();

    virtual bool getNextPose(Eigen::Affine3f & result_pose);

};


#include "frame_provider_empty.h"

FrameProviderEmpty::FrameProviderEmpty() {}

bool FrameProviderEmpty::getNextFrame(cv::Mat & color, cv::Mat & depth)
{
    return false;
}

void FrameProviderEmpty::skipNextFrame()
{
}

void FrameProviderEmpty::reset()
{
    //nothing
}

#pragma once

#include "frame_provider_base.h"
#include "frame_provider_file_wrapper.h"
#include "frame_provider_png.h"
#include "frame_provider_handa.h"
#include "frame_provider_empty.h"
#include "frame_provider_yuyin.h"
#include "frame_provider_freiburg.h"
#include "frame_provider_luis.h"
#include "frame_provider_png_depth.h"
#include "frame_provider_arun.h"



#pragma once

namespace Noise
{
		// Modeling Kinect Sensor Noise for Improved 3D Reconstruction and Tracking (3)
	float simpleAxial(float z);
};

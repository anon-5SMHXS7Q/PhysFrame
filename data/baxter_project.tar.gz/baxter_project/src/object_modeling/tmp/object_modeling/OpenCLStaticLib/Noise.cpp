#include "stdafx.h"
#include "Noise.h"


namespace Noise
{
	// Modeling Kinect Sensor Noise for Improved 3D Reconstruction and Tracking (3)
	float simpleAxial(float z) {
		float w = z - 0.4f;
		return 0.0012f + 0.0019f * w * w;
	}


}; // ns

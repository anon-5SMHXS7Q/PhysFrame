#include "stdafx.h"


#include "ICPCombinedFunctor.hpp"
template class ICPCombinedFunctor<float>;

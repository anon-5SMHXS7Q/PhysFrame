This is a set of files for setting up a Pioneer Robot equipped with a Kinect and running the Robot Operating System with Ubuntu.

Please refer to provided guideline for setup instructions.

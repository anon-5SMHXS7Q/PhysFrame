#ifndef MAPPING_ABSTRACT_HPP
#define MAPPING_ABSTRACT_HPP

#include "basic_function.hpp"

namespace uavos{

}

#endif //MAPPING_ABSTRACT_HPP

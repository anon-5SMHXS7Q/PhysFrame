#include "mapping/mapping_abstract.hpp"

using namespace uavos;

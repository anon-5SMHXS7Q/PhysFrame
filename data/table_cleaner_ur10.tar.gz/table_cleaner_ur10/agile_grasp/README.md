# agile_grasp

* **Author:** Andreas ten Pas (atp@ccs.neu.edu)
* **Version:** 1.0.0
* **ROS Wiki page:** [http://wiki.ros.org/agile_grasp](http://wiki.ros.org/agile_grasp)
* **Author's website:** [http://www.ccs.neu.edu/home/atp/](http://www.ccs.neu.edu/home/atp/)


## 1) Instructions

Please look at http://wiki.ros.org/agile_grasp for detailed instructions.

# Husarion tutorial_pkg #

This repository contains end effect expected by the user after completing set of [ROS tutorials](https://husarion.com/tutorials/ros-tutorials/1-ros-introduction/)


You can use it to verify if you are following tutorials correctly or clone this repository to your workspace and admit that you did all the work.
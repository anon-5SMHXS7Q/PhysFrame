Clone to src folder in catkin_ws

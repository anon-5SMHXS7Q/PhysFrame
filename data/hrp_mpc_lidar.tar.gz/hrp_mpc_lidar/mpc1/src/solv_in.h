#include "cvxgen/solver.h"
#include <stdio.h>

#define CONTROL_DIM 2
#define STATE_DIM 3
#define HORIZON 5

Vars vars;
Params params;
Workspace work;
Settings settings;

class solv_in{
private:
    std::vector<bool> 
public:
    solv_in(/* args */);
    ~solv_in();
};

solv_in::solv_in(/* args */)
{
}

solv_in::~solv_in()
{
}

#include "solv_in.h"

#define CONTROL_DIM 2
#define STATE_DIM 3
#define HORIZON 5

Vars vars;
Params params;
Workspace work;
Settings settings;


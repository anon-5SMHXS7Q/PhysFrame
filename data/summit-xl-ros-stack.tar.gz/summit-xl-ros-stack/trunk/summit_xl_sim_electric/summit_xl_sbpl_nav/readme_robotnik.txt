1-Keep in mind that map resolutions have to be 0.025 !!!!

Test with 

roslaunch summit_xl_sbpl_nav test.launch





# comprobo17
The base repo for the Olin College course "A Computational Introduction to Robotics" Spring 2017.

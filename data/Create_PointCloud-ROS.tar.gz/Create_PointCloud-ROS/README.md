# Point Cloud Generation using a Sick Laser Range Finder LMS-100

##Hardware Especifications:
### Sick LMS-100 laser range finder
### Flir Pan Tilt
### Mobile Robots P3-AT 

### Hardware Assembly:
<img src="https://s16.postimg.org/fmr91x7xx/IMG_20160904_154446986.jpg" width="400"/>


## Point Cloud RViz Visualization:
<img src="https://s22.postimg.org/6ukrgvem9/rviz_screenshot_2016_08_23_15_34_30.png" width="600" height ="600"/>

## Intesity Based Image:
<img src="https://s18.postimg.org/bn488kbp5/frame0000.jpg" width="500"/>








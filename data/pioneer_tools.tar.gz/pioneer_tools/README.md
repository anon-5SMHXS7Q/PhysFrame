pioneer_teleop
==============

Teleoperation node to control a pioneer robot with a joystick. This should work on fuerte as opposed to ROSARIA or p2os packages.
### Total-Text dataset

Home page: https://github.com/cs-chan/Total-Text-Dataset

download dataset and make it to a dataset format

```shell
bash download.sh
```


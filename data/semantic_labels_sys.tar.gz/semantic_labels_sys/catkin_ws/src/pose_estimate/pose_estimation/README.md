# Pose estimate for object or brandname

## The data is logged at {[ee_link] -> [fake_tcp]: 0.0155 0.0 0.0431 0.0 0.0 -0.707 0.707}

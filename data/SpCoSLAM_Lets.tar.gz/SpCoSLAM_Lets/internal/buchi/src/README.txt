﻿csv_send.py 
>>/learning/から/buchi/src/に移動

-------------------------------------------------
更新日時
2018/11/27 Akira Taniguchi

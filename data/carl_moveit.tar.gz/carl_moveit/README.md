carl_moveit [![Build Status](https://api.travis-ci.org/GT-RAIL/carl_moveit.png)](https://travis-ci.org/GT-RAIL/carl_moveit)
===========

#### MoveIt! Configuration and ROS Interface for CARL
For full documentation, see [the ROS wiki](http://ros.org/wiki/carl_moveit).

### License
For full terms and conditions, see the [LICENSE](LICENSE) file.

### Authors
See the [AUTHORS](AUTHORS.md) file for a full list of contributors.

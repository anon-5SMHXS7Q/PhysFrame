Original Authors
----------------

 * [David Kent](davidkent@wpi.edu)

Contributors
------------

 * [Russell Toris](https://github.com/rctoris/) (russell.toris@gmail.com)
 
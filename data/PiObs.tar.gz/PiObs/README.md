# PiObs
ROS tetrapod robot on Raspberry Pi

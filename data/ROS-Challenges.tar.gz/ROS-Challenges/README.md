# ROS Challenges :robot: - Team top number one
Base code written by the teaching staff at U Surrey for the Robotics subject (Richard Bowden, Simon Hadfield, Oscar Mendez, et al.) and was further developed to where this repo is now by this team.
## Robotics challenge

## Challenge 1
Sensor fusion

## Challenge 2
Path planning for exploration search

## Challenge 3
Baxter grasping and moving challenge

## Challenge 4
Octomap rendering for self driving cars

---
Final grade: 85%

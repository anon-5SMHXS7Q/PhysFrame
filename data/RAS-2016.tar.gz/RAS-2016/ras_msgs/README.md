ras_msgs
========

Messages used in the RAS course, mainly for collecting evidence of detected/identified objects.

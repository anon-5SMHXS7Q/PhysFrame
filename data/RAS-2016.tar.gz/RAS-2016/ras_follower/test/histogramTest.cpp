#include <ros/ros.h>

int main(int argc, char **argv)
{
  // Set up ROS.
  ros::init(argc, argv, "histogramTest");

  ROS_INFO("Hello world!");
}

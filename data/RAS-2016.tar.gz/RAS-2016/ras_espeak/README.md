ras_espeak
==========

Node that plays a text string over the computer's speakers with a robotic-like voice (espeak terminal tool).

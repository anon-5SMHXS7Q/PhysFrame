# ras_path_plan

Finish smoothing with 4 times manhattan distance.

Still have something to imporve.

To near to the obstacle.

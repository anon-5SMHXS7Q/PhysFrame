ras_arduino_msgs
==================

This package contains message (.msg) definitions for interfacing via ROS with motors and sensors on the Arduino.

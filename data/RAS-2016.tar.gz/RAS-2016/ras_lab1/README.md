ras_lab1
====================

Source code for running lab 1.

# Robot8 Launchers
Here we store all the launchers for the project. Diffrent launchers for diffrent milestones.

## Dependencis
* [teleop_twist_keyboard](http://wiki.ros.org/teleop_twist_keyboard)
* [laser_pipeline](http://wiki.ros.org/laser_pipeline)

 // Handling Strings in C++  (Tutorial) 	

 // #include <sstream>  								// needed include, for strings in C++
 // std::stringstream ss;     							// creating a str obj 
 // ss << "String"; 									// fill str obj up with text
 // msg.data = ss.str();    							// set str obj to a variable 
 // ROS_INFO("the string is: %s", msg.data.c_str());	// extract string from a pre-filled variable (that contains str) 

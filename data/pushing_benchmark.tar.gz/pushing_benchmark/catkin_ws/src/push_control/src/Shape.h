class Shape
{
public:
    virtual vector<sdaf> findShape() = 0;
}


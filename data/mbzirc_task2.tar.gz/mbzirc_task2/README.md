For TASK2 and some common packages

###Laser board
`
rosrun jsk_mbzirc_board laser_board.py
`

please subscribe to topic /serial_board/point_laser
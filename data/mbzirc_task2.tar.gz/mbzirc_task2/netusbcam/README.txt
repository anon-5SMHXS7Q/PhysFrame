1. download the linux library from http://www.mvision.co.jp/index_driver.htm#net2
2. install the debian package with the correct version
3. also install the libudev from apt-get
4. set synbolic link for the libudev.so.0 (http://askubuntu.com/questions/288821/how-do-i-resolve-a-cannot-open-shared-object-file-libudev-so-0-error)
5. set the duev rult for the camera, please see the README.txt in the library folder


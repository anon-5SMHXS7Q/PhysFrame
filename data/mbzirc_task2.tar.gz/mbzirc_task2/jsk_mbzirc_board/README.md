Please first run the '/scripts/config.sh'  one time first..

# Actrl - Turtlebot + Arm controller
This package includes the various launch files to launch both the turtlebot and the arm together in Gazebo, and programs for its integrated control.

Package that contains URDF of Meka robot. It needs the package "common-sensors"

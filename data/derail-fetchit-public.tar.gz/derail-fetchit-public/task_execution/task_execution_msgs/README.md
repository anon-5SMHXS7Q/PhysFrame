# Task Execution Messages

Defines the interface to the task execution / monitoring nodes

rail_segmentation_tools
=================

#### Post-processing nodes for Rail Segmentation
For full documentation of rail segmentation, see [its page on the ROS wiki](http://ros.org/wiki/rail_segmentation).

### License
rail_segmentation_tools is released with a BSD license. For full terms and conditions, see the [LICENSE](LICENSE) file.

### Authors
See the [AUTHORS.md](AUTHORS.md) file for a full list of contributors.

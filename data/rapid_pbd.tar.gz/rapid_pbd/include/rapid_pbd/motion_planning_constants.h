#ifndef _RAPID_PBD_MOTION_PLANNING_CONSTANTS_H_
#define _RAPID_PBD_MOTION_PLANNING_CONSTANTS_H_

namespace rapid {
namespace pbd {
static const char kCollisionSurfaceName[] =
    "surface_segmentation_collision_table";
}
}  // namespace rapid

#endif  // _RAPID_PBD_MOTION_PLANNING_CONSTANTS_H_

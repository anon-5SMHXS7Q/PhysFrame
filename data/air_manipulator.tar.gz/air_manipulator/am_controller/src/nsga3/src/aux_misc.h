#ifndef MISC_AUX__
#define MISC_AUX__

#include <string>

std::string IntToStr(int i);

#endif
# ae-scoot
This repository contains the codes & drivers used for the autonomous electric scooter project. The project is about using an electric scooter to perform autonomous navigation using Ackermann's Steering. The scooter runs with 64 bit Ubuntu 14.04 and ROS Indigo.

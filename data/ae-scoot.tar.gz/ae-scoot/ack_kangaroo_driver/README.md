Ack Kangaroo Driver (Experimental)

A driver for the motion controller Kangaroo X2, used with the motor controller Sabertooth dual. This repo contains the modified version of the Kangaroo X2 Driver.

It subscribes to cmd_vel of AckermannDrive message type, and publishes odometry to the JointState topic.

/*
 * motion.cpp
 *
 *  Created on: Sep 26, 2012
 *      Author: nishitani
 */

#include "motion.h"

namespace LRM {

MotionEstimator::MotionEstimator() {
	// TODO Auto-generated constructor stub

}

MotionEstimator::~MotionEstimator() {
	// TODO Auto-generated destructor stub
}

} /* namespace LRM */

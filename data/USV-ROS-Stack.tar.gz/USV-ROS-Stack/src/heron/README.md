heron
==========

Lightweight Heron packages common to robot and desktop.

Please see the ROS wiki for details on use: http://wiki.ros.org/Robots/Heron

robot_upstart
=============

Clearpath Robotics presents a suite of scripts to assist with launching background ROS processes on Ubuntu Linux PCs. Please see the [generated documentation](http://docs.ros.org/latest-available/api/robot_upstart/html/) and [ROS Wiki](http://wiki.ros.org/robot_upstart).

um6
===

[![Build Status](https://travis-ci.org/ros-drivers/um6.png?branch=hydro-devel)](https://travis-ci.org/ros-drivers/um6)

ROS driver for UM6 inertial measurement device. Supports standard data and mag topics, as well as providing temperature and rpy outputs. See the ROS wiki for details: http://wiki.ros.org/um6

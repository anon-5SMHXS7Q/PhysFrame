# pose_reasoning

## I/O

### publish

* `/tomato_pedicels (visualization_msgs/Marker)`

### subscribe

* `/branchcloud (sensor_msgs/Pointcloud2)`

### param

* `/tomatocoeff`
* `/gvector`

### tf

* `/pcenter (parent: /camera_rgb_optical_frame)`
* `/ppedicel (parent: /camera_rgb_optical_frame)`


# tomato_seg

## I/O

### publish

* `/branchcloud (sensor_msgs/Pointcloud2)`
* `/tomato_fruites (visualization_msgs/MarkerArray)`

### subscribe

* `/camera_remote/depth_registered/points (sensor_msgs/Pointcloud2)`
* `/camera1_remote/depth_registered/points (sensor_msgs/Pointcloud2)`


### param

* `/Centroid`
* `/SSegment`
* `/colorseg`
* `/Boxsize`
* `/tomatocoeff`


### tf

# denso_tomato

# ros-industrial / universal_robot
sudo apt-get install ros-indigo-ur-bringup ros-indigo-ur-gazebo ros-indigo-ur5-moveit-config ros-indigo-ur-kinematics

# boundary_estimation

## build

```
catkin build boundary_estimation
```

## run

```
roslaunch boundary_estimation boundary_estimation.launch
```

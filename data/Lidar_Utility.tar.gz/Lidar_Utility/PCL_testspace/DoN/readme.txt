cd build
cmake ..
make

 ./don_segmentation ~/Lidar_Utility/PointCloudData/pcd/velodyne1/2826laser.pcd 10 20 .1 .5


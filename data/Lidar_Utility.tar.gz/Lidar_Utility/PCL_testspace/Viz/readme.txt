cd build
cmake ..
make
./cloud_viewer

cd build
cmake ..
make
./hV

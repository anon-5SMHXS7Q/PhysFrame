/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Jul 18 16:26:00 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QGraphicsView>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListView>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QScrollBar>
#include <QtGui/QSlider>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QTextBrowser>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <QtWebKit/QWebView>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_2;
    QTabWidget *tabWidget;
    QWidget *tab_5;
    QGridLayout *gridLayout_24;
    QTabWidget *tabWidget_5;
    QWidget *widget;
    QGridLayout *gridLayout_25;
    QLabel *label_10;
    QLineEdit *Master;
    QLabel *label_39;
    QLineEdit *Host;
    QPushButton *connect;
    QCheckBox *environmentcheckbox;
    QTabWidget *tabWidget_8;
    QWidget *Select;
    QGridLayout *gridLayout_28;
    QRadioButton *radioButton_9;
    QRadioButton *radioButton_10;
    QTabWidget *DeviceAttached;
    QWidget *tab_27;
    QListView *listView;
    QWidget *tab_20;
    QGridLayout *gridLayout_26;
    QLabel *label_41;
    QCheckBox *checkBox_2;
    QPushButton *quitButton;
    QWidget *tab;
    QGridLayout *gridLayout;
    QTabWidget *arm;
    QWidget *armPage1;
    QGridLayout *gridLayout_6;
    QFrame *frame_4;
    QGridLayout *gridLayout_11;
    QLabel *label_3;
    QLCDNumber *lcdNumber;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_6;
    QFrame *frame_5;
    QGridLayout *gridLayout_12;
    QLabel *label_4;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_7;
    QLCDNumber *lcdNumber_2;
    QLabel *label_6;
    QFrame *frame;
    QWidget *tab_11;
    QGridLayout *gridLayout_10;
    QFrame *frame_3;
    QGridLayout *gridLayout_14;
    QRadioButton *radioButton;
    QFrame *frame_7;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_5;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *radioButton_2;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_12;
    QFrame *frame_2;
    QGridLayout *gridLayout_13;
    QFrame *frame_8;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_11;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_3;
    QLCDNumber *lcdNumber_3;
    QLabel *label_7;
    QLabel *label_8;
    QTabWidget *camera;
    QWidget *tab_9;
    QGridLayout *gridLayout_15;
    QGraphicsView *graphicsView_4;
    QWidget *cameraPage1;
    QGridLayout *gridLayout_4;
    QGraphicsView *graphicsView;
    QWidget *tab_16;
    QGraphicsView *graphicsView_10;
    QWidget *tab_7;
    QGridLayout *gridLayout_8;
    QGraphicsView *graphicsView_2;
    QWidget *tab_8;
    QGridLayout *gridLayout_9;
    QGraphicsView *graphicsView_3;
    QWidget *tab_21;
    QGridLayout *gridLayout_31;
    QGraphicsView *graphicsView_5;
    QHBoxLayout *horizontalLayout;
    QTabWidget *drive;
    QWidget *drivePage1;
    QGridLayout *gridLayout_3;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *label_21;
    QWidget *tab_13;
    QGridLayout *gridLayout_17;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_25;
    QSlider *horizontalSlider;
    QSlider *verticalSlider;
    QLCDNumber *lcdNumber_6;
    QLabel *label_34;
    QLCDNumber *lcdNumber_7;
    QLabel *label_35;
    QWidget *tab_25;
    QSpinBox *MOVE_SPEEDSWITCH;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_35;
    QPushButton *Forward;
    QPushButton *TURNLEFT;
    QPushButton *STOP;
    QPushButton *TURNRIGHT;
    QPushButton *BACKWARD;
    QSpinBox *TURNING_SPEEDSWITCH;
    QLabel *label_44;
    QLabel *label_45;
    QTabWidget *tabWidget_2;
    QWidget *tab_12;
    QLabel *label_13;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_14;
    QLCDNumber *lcdNumber_8;
    QLabel *label_36;
    QProgressBar *progressBar;
    QWidget *tab_14;
    QGridLayout *gridLayout_20;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLabel *label_32;
    QLCDNumber *lcdNumber_9;
    QLCDNumber *lcdNumber_10;
    QLCDNumber *lcdNumber_11;
    QLCDNumber *lcdNumber_12;
    QLCDNumber *lcdNumber_14;
    QLCDNumber *lcdNumber_13;
    QWidget *tab_10;
    QGridLayout *gridLayout_5;
    QLabel *label_24;
    QLabel *label_26;
    QLabel *label_40;
    QLabel *label_19;
    QWidget *tab_23;
    QSlider *Pan_control_bar;
    QSlider *Tilt_control_bar;
    QPushButton *PanTilt_Reset;
    QWidget *tab_26;
    QLabel *label_42;
    QLabel *label_43;
    QLCDNumber *left_encoder_value;
    QLCDNumber *right_encoder_value;
    QWidget *tab_6;
    QGridLayout *gridLayout_30;
    QGridLayout *gridLayout_19;
    QLabel *label_20;
    QLabel *label_18;
    QProgressBar *progressBar_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_33;
    QLabel *label_15;
    QGraphicsView *graphicsView_6;
    QGraphicsView *graphicsView_7;
    QTabWidget *camera_2;
    QWidget *tab_19;
    QGridLayout *gridLayout_32;
    QGraphicsView *graphicsView_13;
    QWidget *cameraPage1_2;
    QGridLayout *gridLayout_7;
    QGraphicsView *graphicsView_14;
    QScrollBar *verticalScrollBar_3;
    QScrollBar *horizontalScrollBar_3;
    QWidget *tab_22;
    QGridLayout *gridLayout_33;
    QGraphicsView *graphicsView_15;
    QWidget *tab_24;
    QGridLayout *gridLayout_34;
    QGraphicsView *graphicsView_16;
    QWidget *tab_2;
    QGridLayout *gridLayout_16;
    QWebView *webView;
    QListWidget *listWidget;
    QGridLayout *gridLayout_18;
    QLabel *label_16;
    QLCDNumber *lcdNumber_4;
    QLabel *label_17;
    QLCDNumber *lcdNumber_5;
    QLabel *label_9;
    QSpinBox *spinBox;
    QLabel *label_37;
    QComboBox *comboBox;
    QLabel *label_38;
    QSpinBox *spinBox_2;
    QPushButton *start_gps;
    QPushButton *sto_gps;
    QPushButton *load_gps;
    QPushButton *save_gps;
    QWidget *tab_4;
    QGridLayout *gridLayout_21;
    QTabWidget *tabWidget_3;
    QWidget *tab_15;
    QGridLayout *gridLayout_22;
    QGraphicsView *graphicsView_8;
    QTabWidget *tabWidget_4;
    QWidget *tab_17;
    QGridLayout *gridLayout_23;
    QGraphicsView *graphicsView_9;
    QTabWidget *tabWidget_6;
    QWidget *tab_3;
    QGridLayout *gridLayout_27;
    QTextBrowser *textBrowser;
    QWidget *tab_18;
    QGridLayout *gridLayout_29;
    QRadioButton *radioButton_11;
    QRadioButton *radioButton_12;
    QCheckBox *checkBox;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setWindowModality(Qt::NonModal);
        MainWindow->resize(1458, 805);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setContextMenuPolicy(Qt::DefaultContextMenu);
        MainWindow->setAutoFillBackground(true);
        MainWindow->setAnimated(false);
        MainWindow->setDockOptions(QMainWindow::AllowTabbedDocks);
        MainWindow->setUnifiedTitleAndToolBarOnMac(true);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout_2 = new QGridLayout(centralWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy1);
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        gridLayout_24 = new QGridLayout(tab_5);
        gridLayout_24->setSpacing(6);
        gridLayout_24->setContentsMargins(11, 11, 11, 11);
        gridLayout_24->setObjectName(QString::fromUtf8("gridLayout_24"));
        tabWidget_5 = new QTabWidget(tab_5);
        tabWidget_5->setObjectName(QString::fromUtf8("tabWidget_5"));
        widget = new QWidget();
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_25 = new QGridLayout(widget);
        gridLayout_25->setSpacing(6);
        gridLayout_25->setContentsMargins(11, 11, 11, 11);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        label_10 = new QLabel(widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_25->addWidget(label_10, 0, 0, 1, 1);

        Master = new QLineEdit(widget);
        Master->setObjectName(QString::fromUtf8("Master"));

        gridLayout_25->addWidget(Master, 0, 1, 1, 1);

        label_39 = new QLabel(widget);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        gridLayout_25->addWidget(label_39, 1, 0, 1, 1);

        Host = new QLineEdit(widget);
        Host->setObjectName(QString::fromUtf8("Host"));

        gridLayout_25->addWidget(Host, 1, 1, 1, 1);

        connect = new QPushButton(widget);
        connect->setObjectName(QString::fromUtf8("connect"));
        connect->setMaximumSize(QSize(100, 16777215));

        gridLayout_25->addWidget(connect, 3, 1, 1, 1);

        environmentcheckbox = new QCheckBox(widget);
        environmentcheckbox->setObjectName(QString::fromUtf8("environmentcheckbox"));

        gridLayout_25->addWidget(environmentcheckbox, 2, 1, 1, 1);

        tabWidget_5->addTab(widget, QString());

        gridLayout_24->addWidget(tabWidget_5, 0, 0, 1, 1);

        tabWidget_8 = new QTabWidget(tab_5);
        tabWidget_8->setObjectName(QString::fromUtf8("tabWidget_8"));
        Select = new QWidget();
        Select->setObjectName(QString::fromUtf8("Select"));
        gridLayout_28 = new QGridLayout(Select);
        gridLayout_28->setSpacing(6);
        gridLayout_28->setContentsMargins(11, 11, 11, 11);
        gridLayout_28->setObjectName(QString::fromUtf8("gridLayout_28"));
        radioButton_9 = new QRadioButton(Select);
        radioButton_9->setObjectName(QString::fromUtf8("radioButton_9"));
        radioButton_9->setChecked(true);

        gridLayout_28->addWidget(radioButton_9, 0, 0, 1, 1);

        radioButton_10 = new QRadioButton(Select);
        radioButton_10->setObjectName(QString::fromUtf8("radioButton_10"));

        gridLayout_28->addWidget(radioButton_10, 1, 0, 1, 1);

        tabWidget_8->addTab(Select, QString());

        gridLayout_24->addWidget(tabWidget_8, 0, 1, 1, 1);

        DeviceAttached = new QTabWidget(tab_5);
        DeviceAttached->setObjectName(QString::fromUtf8("DeviceAttached"));
        tab_27 = new QWidget();
        tab_27->setObjectName(QString::fromUtf8("tab_27"));
        listView = new QListView(tab_27);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(50, 20, 331, 231));
        DeviceAttached->addTab(tab_27, QString());
        tab_20 = new QWidget();
        tab_20->setObjectName(QString::fromUtf8("tab_20"));
        gridLayout_26 = new QGridLayout(tab_20);
        gridLayout_26->setSpacing(6);
        gridLayout_26->setContentsMargins(11, 11, 11, 11);
        gridLayout_26->setObjectName(QString::fromUtf8("gridLayout_26"));
        label_41 = new QLabel(tab_20);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        gridLayout_26->addWidget(label_41, 0, 0, 1, 1);

        checkBox_2 = new QCheckBox(tab_20);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setChecked(true);
        checkBox_2->setTristate(false);

        gridLayout_26->addWidget(checkBox_2, 0, 1, 1, 1);

        DeviceAttached->addTab(tab_20, QString());

        gridLayout_24->addWidget(DeviceAttached, 1, 0, 1, 1);

        quitButton = new QPushButton(tab_5);
        quitButton->setObjectName(QString::fromUtf8("quitButton"));

        gridLayout_24->addWidget(quitButton, 1, 1, 1, 1);

        tabWidget->addTab(tab_5, QString());
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout = new QGridLayout(tab);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        arm = new QTabWidget(tab);
        arm->setObjectName(QString::fromUtf8("arm"));
        sizePolicy1.setHeightForWidth(arm->sizePolicy().hasHeightForWidth());
        arm->setSizePolicy(sizePolicy1);
        armPage1 = new QWidget();
        armPage1->setObjectName(QString::fromUtf8("armPage1"));
        gridLayout_6 = new QGridLayout(armPage1);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        frame_4 = new QFrame(armPage1);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        sizePolicy1.setHeightForWidth(frame_4->sizePolicy().hasHeightForWidth());
        frame_4->setSizePolicy(sizePolicy1);
        frame_4->setFrameShape(QFrame::Panel);
        frame_4->setFrameShadow(QFrame::Raised);
        gridLayout_11 = new QGridLayout(frame_4);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        label_3 = new QLabel(frame_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy2);

        gridLayout_11->addWidget(label_3, 0, 0, 1, 1);

        lcdNumber = new QLCDNumber(frame_4);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lcdNumber->sizePolicy().hasHeightForWidth());
        lcdNumber->setSizePolicy(sizePolicy3);
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        lcdNumber->setFont(font);
        lcdNumber->setLineWidth(0);
        lcdNumber->setSmallDecimalPoint(false);
        lcdNumber->setProperty("value", QVariant(0));
        lcdNumber->setProperty("intValue", QVariant(0));

        gridLayout_11->addWidget(lcdNumber, 0, 2, 1, 1);

        radioButton_5 = new QRadioButton(frame_4);
        radioButton_5->setObjectName(QString::fromUtf8("radioButton_5"));
        sizePolicy1.setHeightForWidth(radioButton_5->sizePolicy().hasHeightForWidth());
        radioButton_5->setSizePolicy(sizePolicy1);
        radioButton_5->setChecked(true);

        gridLayout_11->addWidget(radioButton_5, 2, 0, 1, 1);

        radioButton_6 = new QRadioButton(frame_4);
        radioButton_6->setObjectName(QString::fromUtf8("radioButton_6"));
        sizePolicy1.setHeightForWidth(radioButton_6->sizePolicy().hasHeightForWidth());
        radioButton_6->setSizePolicy(sizePolicy1);

        gridLayout_11->addWidget(radioButton_6, 2, 2, 1, 1);


        gridLayout_6->addWidget(frame_4, 2, 0, 1, 1);

        frame_5 = new QFrame(armPage1);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        sizePolicy1.setHeightForWidth(frame_5->sizePolicy().hasHeightForWidth());
        frame_5->setSizePolicy(sizePolicy1);
        frame_5->setFrameShape(QFrame::Panel);
        frame_5->setFrameShadow(QFrame::Raised);
        gridLayout_12 = new QGridLayout(frame_5);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        label_4 = new QLabel(frame_5);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        sizePolicy2.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy2);

        gridLayout_12->addWidget(label_4, 0, 0, 1, 1);

        radioButton_8 = new QRadioButton(frame_5);
        radioButton_8->setObjectName(QString::fromUtf8("radioButton_8"));
        sizePolicy1.setHeightForWidth(radioButton_8->sizePolicy().hasHeightForWidth());
        radioButton_8->setSizePolicy(sizePolicy1);

        gridLayout_12->addWidget(radioButton_8, 2, 1, 1, 1);

        radioButton_7 = new QRadioButton(frame_5);
        radioButton_7->setObjectName(QString::fromUtf8("radioButton_7"));
        sizePolicy1.setHeightForWidth(radioButton_7->sizePolicy().hasHeightForWidth());
        radioButton_7->setSizePolicy(sizePolicy1);
        radioButton_7->setChecked(true);

        gridLayout_12->addWidget(radioButton_7, 2, 0, 1, 1);

        lcdNumber_2 = new QLCDNumber(frame_5);
        lcdNumber_2->setObjectName(QString::fromUtf8("lcdNumber_2"));
        sizePolicy3.setHeightForWidth(lcdNumber_2->sizePolicy().hasHeightForWidth());
        lcdNumber_2->setSizePolicy(sizePolicy3);
        lcdNumber_2->setFont(font);
        lcdNumber_2->setLineWidth(0);

        gridLayout_12->addWidget(lcdNumber_2, 0, 1, 1, 1);


        gridLayout_6->addWidget(frame_5, 2, 2, 1, 1);

        label_6 = new QLabel(armPage1);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        QSizePolicy sizePolicy4(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy4);
        label_6->setMinimumSize(QSize(210, 110));
        label_6->setMaximumSize(QSize(210, 110));
        label_6->setFrameShape(QFrame::NoFrame);
        label_6->setText(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/arm.png\" /></p></body></html>"));
        label_6->setTextFormat(Qt::AutoText);
        label_6->setScaledContents(true);
        label_6->setOpenExternalLinks(false);

        gridLayout_6->addWidget(label_6, 0, 2, 1, 1);

        frame = new QFrame(armPage1);
        frame->setObjectName(QString::fromUtf8("frame"));
        sizePolicy4.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy4);
        frame->setMinimumSize(QSize(210, 110));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);

        gridLayout_6->addWidget(frame, 0, 0, 1, 1);

        arm->addTab(armPage1, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName(QString::fromUtf8("tab_11"));
        gridLayout_10 = new QGridLayout(tab_11);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        frame_3 = new QFrame(tab_11);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        sizePolicy1.setHeightForWidth(frame_3->sizePolicy().hasHeightForWidth());
        frame_3->setSizePolicy(sizePolicy1);
        frame_3->setFrameShape(QFrame::Panel);
        frame_3->setFrameShadow(QFrame::Raised);
        gridLayout_14 = new QGridLayout(frame_3);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        radioButton = new QRadioButton(frame_3);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setChecked(true);

        gridLayout_14->addWidget(radioButton, 1, 4, 1, 1);

        frame_7 = new QFrame(frame_3);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        sizePolicy4.setHeightForWidth(frame_7->sizePolicy().hasHeightForWidth());
        frame_7->setSizePolicy(sizePolicy4);
        frame_7->setMinimumSize(QSize(50, 50));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);

        gridLayout_14->addWidget(frame_7, 0, 2, 3, 1);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_5 = new QLabel(frame_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_4->addWidget(label_5);


        gridLayout_14->addLayout(verticalLayout_4, 0, 3, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        radioButton_2 = new QRadioButton(frame_3);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));

        verticalLayout_3->addWidget(radioButton_2);


        gridLayout_14->addLayout(verticalLayout_3, 1, 5, 1, 1);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_12 = new QLabel(frame_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        sizePolicy4.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy4);
        label_12->setMinimumSize(QSize(50, 50));
        label_12->setMaximumSize(QSize(50, 50));

        verticalLayout_7->addWidget(label_12);


        gridLayout_14->addLayout(verticalLayout_7, 0, 0, 3, 1);


        gridLayout_10->addWidget(frame_3, 1, 0, 1, 1);

        frame_2 = new QFrame(tab_11);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        sizePolicy1.setHeightForWidth(frame_2->sizePolicy().hasHeightForWidth());
        frame_2->setSizePolicy(sizePolicy1);
        frame_2->setFrameShape(QFrame::Panel);
        frame_2->setFrameShadow(QFrame::Raised);
        gridLayout_13 = new QGridLayout(frame_2);
        gridLayout_13->setSpacing(6);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        frame_8 = new QFrame(frame_2);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        sizePolicy4.setHeightForWidth(frame_8->sizePolicy().hasHeightForWidth());
        frame_8->setSizePolicy(sizePolicy4);
        frame_8->setMinimumSize(QSize(50, 50));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);

        gridLayout_13->addWidget(frame_8, 0, 1, 4, 1);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_11 = new QLabel(frame_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy4.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy4);
        label_11->setMinimumSize(QSize(50, 50));
        label_11->setMaximumSize(QSize(50, 50));

        verticalLayout_8->addWidget(label_11);


        gridLayout_13->addLayout(verticalLayout_8, 0, 0, 4, 1);

        radioButton_4 = new QRadioButton(frame_2);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));

        gridLayout_13->addWidget(radioButton_4, 3, 4, 1, 1);

        radioButton_3 = new QRadioButton(frame_2);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setChecked(true);

        gridLayout_13->addWidget(radioButton_3, 3, 3, 1, 1);

        lcdNumber_3 = new QLCDNumber(frame_2);
        lcdNumber_3->setObjectName(QString::fromUtf8("lcdNumber_3"));
        sizePolicy1.setHeightForWidth(lcdNumber_3->sizePolicy().hasHeightForWidth());
        lcdNumber_3->setSizePolicy(sizePolicy1);
        lcdNumber_3->setLineWidth(0);

        gridLayout_13->addWidget(lcdNumber_3, 1, 4, 1, 1);

        label_7 = new QLabel(frame_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        sizePolicy1.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy1);

        gridLayout_13->addWidget(label_7, 1, 3, 1, 1);

        label_8 = new QLabel(frame_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_13->addWidget(label_8, 1, 2, 1, 1);


        gridLayout_10->addWidget(frame_2, 0, 0, 1, 1);

        arm->addTab(tab_11, QString());

        gridLayout->addWidget(arm, 2, 0, 1, 1);

        camera = new QTabWidget(tab);
        camera->setObjectName(QString::fromUtf8("camera"));
        sizePolicy1.setHeightForWidth(camera->sizePolicy().hasHeightForWidth());
        camera->setSizePolicy(sizePolicy1);
        camera->setFocusPolicy(Qt::NoFocus);
        camera->setTabPosition(QTabWidget::North);
        camera->setTabShape(QTabWidget::Rounded);
        camera->setElideMode(Qt::ElideNone);
        camera->setUsesScrollButtons(true);
        tab_9 = new QWidget();
        tab_9->setObjectName(QString::fromUtf8("tab_9"));
        gridLayout_15 = new QGridLayout(tab_9);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        graphicsView_4 = new QGraphicsView(tab_9);
        graphicsView_4->setObjectName(QString::fromUtf8("graphicsView_4"));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(graphicsView_4->sizePolicy().hasHeightForWidth());
        graphicsView_4->setSizePolicy(sizePolicy5);
        graphicsView_4->setFocusPolicy(Qt::NoFocus);
        graphicsView_4->setFrameShadow(QFrame::Plain);
        graphicsView_4->setInteractive(true);
        graphicsView_4->setSceneRect(QRectF(0, 0, 0, 0));
        graphicsView_4->setRenderHints(QPainter::Antialiasing|QPainter::SmoothPixmapTransform);
        graphicsView_4->setDragMode(QGraphicsView::ScrollHandDrag);
        graphicsView_4->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_4->setResizeAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_4->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);

        gridLayout_15->addWidget(graphicsView_4, 0, 0, 1, 1);

        camera->addTab(tab_9, QString());
        cameraPage1 = new QWidget();
        cameraPage1->setObjectName(QString::fromUtf8("cameraPage1"));
        gridLayout_4 = new QGridLayout(cameraPage1);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        graphicsView = new QGraphicsView(cameraPage1);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        sizePolicy1.setHeightForWidth(graphicsView->sizePolicy().hasHeightForWidth());
        graphicsView->setSizePolicy(sizePolicy1);
        graphicsView->setMaximumSize(QSize(643, 483));
        graphicsView->setFocusPolicy(Qt::NoFocus);

        gridLayout_4->addWidget(graphicsView, 0, 0, 2, 2);

        camera->addTab(cameraPage1, QString());
        tab_16 = new QWidget();
        tab_16->setObjectName(QString::fromUtf8("tab_16"));
        graphicsView_10 = new QGraphicsView(tab_16);
        graphicsView_10->setObjectName(QString::fromUtf8("graphicsView_10"));
        graphicsView_10->setGeometry(QRect(10, 30, 681, 601));
        camera->addTab(tab_16, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QString::fromUtf8("tab_7"));
        gridLayout_8 = new QGridLayout(tab_7);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        graphicsView_2 = new QGraphicsView(tab_7);
        graphicsView_2->setObjectName(QString::fromUtf8("graphicsView_2"));
        sizePolicy1.setHeightForWidth(graphicsView_2->sizePolicy().hasHeightForWidth());
        graphicsView_2->setSizePolicy(sizePolicy1);
        graphicsView_2->setMaximumSize(QSize(643, 483));
        graphicsView_2->setFocusPolicy(Qt::NoFocus);

        gridLayout_8->addWidget(graphicsView_2, 0, 0, 1, 1);

        camera->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QString::fromUtf8("tab_8"));
        gridLayout_9 = new QGridLayout(tab_8);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        graphicsView_3 = new QGraphicsView(tab_8);
        graphicsView_3->setObjectName(QString::fromUtf8("graphicsView_3"));
        sizePolicy1.setHeightForWidth(graphicsView_3->sizePolicy().hasHeightForWidth());
        graphicsView_3->setSizePolicy(sizePolicy1);
        graphicsView_3->setMaximumSize(QSize(643, 483));
        graphicsView_3->setFocusPolicy(Qt::NoFocus);

        gridLayout_9->addWidget(graphicsView_3, 0, 0, 1, 1);

        camera->addTab(tab_8, QString());
        tab_21 = new QWidget();
        tab_21->setObjectName(QString::fromUtf8("tab_21"));
        gridLayout_31 = new QGridLayout(tab_21);
        gridLayout_31->setSpacing(6);
        gridLayout_31->setContentsMargins(11, 11, 11, 11);
        gridLayout_31->setObjectName(QString::fromUtf8("gridLayout_31"));
        graphicsView_5 = new QGraphicsView(tab_21);
        graphicsView_5->setObjectName(QString::fromUtf8("graphicsView_5"));
        sizePolicy1.setHeightForWidth(graphicsView_5->sizePolicy().hasHeightForWidth());
        graphicsView_5->setSizePolicy(sizePolicy1);
        graphicsView_5->setFocusPolicy(Qt::NoFocus);

        gridLayout_31->addWidget(graphicsView_5, 0, 0, 1, 1);

        camera->addTab(tab_21, QString());

        gridLayout->addWidget(camera, 1, 6, 2, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        drive = new QTabWidget(tab);
        drive->setObjectName(QString::fromUtf8("drive"));
        sizePolicy1.setHeightForWidth(drive->sizePolicy().hasHeightForWidth());
        drive->setSizePolicy(sizePolicy1);
        drivePage1 = new QWidget();
        drivePage1->setObjectName(QString::fromUtf8("drivePage1"));
        gridLayout_3 = new QGridLayout(drivePage1);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label = new QLabel(drivePage1);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy4.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy4);
        label->setMinimumSize(QSize(222, 102));
        label->setMaximumSize(QSize(222, 102));
        label->setScaledContents(true);

        gridLayout_3->addWidget(label, 1, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(drivePage1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy4.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy4);
        label_2->setMinimumSize(QSize(52, 52));
        label_2->setMaximumSize(QSize(52, 52));
        label_2->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_2->setScaledContents(true);

        horizontalLayout_2->addWidget(label_2);

        label_21 = new QLabel(drivePage1);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setMinimumSize(QSize(50, 50));
        label_21->setMaximumSize(QSize(50, 50));

        horizontalLayout_2->addWidget(label_21);


        gridLayout_3->addLayout(horizontalLayout_2, 0, 0, 1, 1);

        drive->addTab(drivePage1, QString());
        tab_13 = new QWidget();
        tab_13->setObjectName(QString::fromUtf8("tab_13"));
        gridLayout_17 = new QGridLayout(tab_13);
        gridLayout_17->setSpacing(6);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        label_22 = new QLabel(tab_13);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout_17->addWidget(label_22, 0, 2, 1, 4);

        label_23 = new QLabel(tab_13);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        sizePolicy1.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy1);

        gridLayout_17->addWidget(label_23, 5, 2, 0, 6);

        label_25 = new QLabel(tab_13);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout_17->addWidget(label_25, 0, 9, 1, 2);

        horizontalSlider = new QSlider(tab_13);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setMinimum(-100);
        horizontalSlider->setMaximum(100);
        horizontalSlider->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(horizontalSlider, 3, 2, 1, 9);

        verticalSlider = new QSlider(tab_13);
        verticalSlider->setObjectName(QString::fromUtf8("verticalSlider"));
        QSizePolicy sizePolicy6(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(verticalSlider->sizePolicy().hasHeightForWidth());
        verticalSlider->setSizePolicy(sizePolicy6);
        verticalSlider->setMinimum(-100);
        verticalSlider->setMaximum(100);
        verticalSlider->setOrientation(Qt::Vertical);

        gridLayout_17->addWidget(verticalSlider, 0, 1, 4, 1);

        lcdNumber_6 = new QLCDNumber(tab_13);
        lcdNumber_6->setObjectName(QString::fromUtf8("lcdNumber_6"));
        sizePolicy1.setHeightForWidth(lcdNumber_6->sizePolicy().hasHeightForWidth());
        lcdNumber_6->setSizePolicy(sizePolicy1);
        lcdNumber_6->setLineWidth(0);
        lcdNumber_6->setDigitCount(4);

        gridLayout_17->addWidget(lcdNumber_6, 1, 2, 1, 1);

        label_34 = new QLabel(tab_13);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        gridLayout_17->addWidget(label_34, 1, 3, 1, 1);

        lcdNumber_7 = new QLCDNumber(tab_13);
        lcdNumber_7->setObjectName(QString::fromUtf8("lcdNumber_7"));
        sizePolicy1.setHeightForWidth(lcdNumber_7->sizePolicy().hasHeightForWidth());
        lcdNumber_7->setSizePolicy(sizePolicy1);
        lcdNumber_7->setLineWidth(0);
        lcdNumber_7->setDigitCount(4);

        gridLayout_17->addWidget(lcdNumber_7, 1, 9, 1, 1);

        label_35 = new QLabel(tab_13);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        gridLayout_17->addWidget(label_35, 1, 10, 1, 1);

        drive->addTab(tab_13, QString());
        tab_25 = new QWidget();
        tab_25->setObjectName(QString::fromUtf8("tab_25"));
        MOVE_SPEEDSWITCH = new QSpinBox(tab_25);
        MOVE_SPEEDSWITCH->setObjectName(QString::fromUtf8("MOVE_SPEEDSWITCH"));
        MOVE_SPEEDSWITCH->setGeometry(QRect(150, 30, 121, 27));
        layoutWidget = new QWidget(tab_25);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 170, 269, 95));
        gridLayout_35 = new QGridLayout(layoutWidget);
        gridLayout_35->setSpacing(6);
        gridLayout_35->setContentsMargins(11, 11, 11, 11);
        gridLayout_35->setObjectName(QString::fromUtf8("gridLayout_35"));
        gridLayout_35->setContentsMargins(0, 0, 0, 0);
        Forward = new QPushButton(layoutWidget);
        Forward->setObjectName(QString::fromUtf8("Forward"));

        gridLayout_35->addWidget(Forward, 0, 1, 1, 1);

        TURNLEFT = new QPushButton(layoutWidget);
        TURNLEFT->setObjectName(QString::fromUtf8("TURNLEFT"));

        gridLayout_35->addWidget(TURNLEFT, 1, 0, 1, 1);

        STOP = new QPushButton(layoutWidget);
        STOP->setObjectName(QString::fromUtf8("STOP"));

        gridLayout_35->addWidget(STOP, 1, 1, 1, 1);

        TURNRIGHT = new QPushButton(layoutWidget);
        TURNRIGHT->setObjectName(QString::fromUtf8("TURNRIGHT"));

        gridLayout_35->addWidget(TURNRIGHT, 1, 2, 1, 1);

        BACKWARD = new QPushButton(layoutWidget);
        BACKWARD->setObjectName(QString::fromUtf8("BACKWARD"));

        gridLayout_35->addWidget(BACKWARD, 2, 1, 1, 1);

        TURNING_SPEEDSWITCH = new QSpinBox(tab_25);
        TURNING_SPEEDSWITCH->setObjectName(QString::fromUtf8("TURNING_SPEEDSWITCH"));
        TURNING_SPEEDSWITCH->setGeometry(QRect(150, 100, 121, 27));
        label_44 = new QLabel(tab_25);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setGeometry(QRect(30, 30, 101, 31));
        label_45 = new QLabel(tab_25);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setGeometry(QRect(20, 100, 101, 31));
        drive->addTab(tab_25, QString());
        layoutWidget->raise();
        MOVE_SPEEDSWITCH->raise();
        TURNING_SPEEDSWITCH->raise();
        label_44->raise();
        label_45->raise();

        horizontalLayout->addWidget(drive);

        tabWidget_2 = new QTabWidget(tab);
        tabWidget_2->setObjectName(QString::fromUtf8("tabWidget_2"));
        sizePolicy1.setHeightForWidth(tabWidget_2->sizePolicy().hasHeightForWidth());
        tabWidget_2->setSizePolicy(sizePolicy1);
        tab_12 = new QWidget();
        tab_12->setObjectName(QString::fromUtf8("tab_12"));
        label_13 = new QLabel(tab_12);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(9, 75, 16, 17));
        layoutWidget1 = new QWidget(tab_12);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(21, 32, 261, 191));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_14 = new QLabel(layoutWidget1);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        sizePolicy1.setHeightForWidth(label_14->sizePolicy().hasHeightForWidth());
        label_14->setSizePolicy(sizePolicy1);

        horizontalLayout_4->addWidget(label_14);

        lcdNumber_8 = new QLCDNumber(layoutWidget1);
        lcdNumber_8->setObjectName(QString::fromUtf8("lcdNumber_8"));
        sizePolicy1.setHeightForWidth(lcdNumber_8->sizePolicy().hasHeightForWidth());
        lcdNumber_8->setSizePolicy(sizePolicy1);
        lcdNumber_8->setLineWidth(0);

        horizontalLayout_4->addWidget(lcdNumber_8);

        label_36 = new QLabel(layoutWidget1);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        horizontalLayout_4->addWidget(label_36);


        verticalLayout->addLayout(horizontalLayout_4);

        progressBar = new QProgressBar(layoutWidget1);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        sizePolicy1.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy1);
        progressBar->setMaximumSize(QSize(1677, 1677));
        progressBar->setLayoutDirection(Qt::LeftToRight);
        progressBar->setValue(100);
        progressBar->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        progressBar->setTextVisible(true);
        progressBar->setOrientation(Qt::Horizontal);
        progressBar->setInvertedAppearance(false);

        verticalLayout->addWidget(progressBar);

        tabWidget_2->addTab(tab_12, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName(QString::fromUtf8("tab_14"));
        gridLayout_20 = new QGridLayout(tab_14);
        gridLayout_20->setSpacing(6);
        gridLayout_20->setContentsMargins(11, 11, 11, 11);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        label_27 = new QLabel(tab_14);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout_20->addWidget(label_27, 0, 0, 1, 2);

        label_28 = new QLabel(tab_14);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout_20->addWidget(label_28, 1, 0, 1, 1);

        label_29 = new QLabel(tab_14);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        gridLayout_20->addWidget(label_29, 2, 0, 1, 1);

        label_30 = new QLabel(tab_14);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        gridLayout_20->addWidget(label_30, 3, 0, 1, 2);

        label_31 = new QLabel(tab_14);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        gridLayout_20->addWidget(label_31, 4, 0, 1, 1);

        label_32 = new QLabel(tab_14);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        gridLayout_20->addWidget(label_32, 5, 0, 1, 1);

        lcdNumber_9 = new QLCDNumber(tab_14);
        lcdNumber_9->setObjectName(QString::fromUtf8("lcdNumber_9"));
        lcdNumber_9->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_9, 0, 2, 1, 1);

        lcdNumber_10 = new QLCDNumber(tab_14);
        lcdNumber_10->setObjectName(QString::fromUtf8("lcdNumber_10"));
        lcdNumber_10->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_10, 1, 2, 1, 1);

        lcdNumber_11 = new QLCDNumber(tab_14);
        lcdNumber_11->setObjectName(QString::fromUtf8("lcdNumber_11"));
        lcdNumber_11->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_11, 2, 2, 1, 1);

        lcdNumber_12 = new QLCDNumber(tab_14);
        lcdNumber_12->setObjectName(QString::fromUtf8("lcdNumber_12"));
        lcdNumber_12->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_12, 3, 2, 1, 1);

        lcdNumber_14 = new QLCDNumber(tab_14);
        lcdNumber_14->setObjectName(QString::fromUtf8("lcdNumber_14"));
        lcdNumber_14->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_14, 5, 2, 1, 1);

        lcdNumber_13 = new QLCDNumber(tab_14);
        lcdNumber_13->setObjectName(QString::fromUtf8("lcdNumber_13"));
        lcdNumber_13->setLineWidth(0);

        gridLayout_20->addWidget(lcdNumber_13, 4, 2, 1, 1);

        tabWidget_2->addTab(tab_14, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QString::fromUtf8("tab_10"));
        gridLayout_5 = new QGridLayout(tab_10);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_24 = new QLabel(tab_10);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout_5->addWidget(label_24, 0, 2, 1, 1);

        label_26 = new QLabel(tab_10);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_5->addWidget(label_26, 1, 0, 1, 1);

        label_40 = new QLabel(tab_10);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        gridLayout_5->addWidget(label_40, 1, 2, 1, 1);

        label_19 = new QLabel(tab_10);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_5->addWidget(label_19, 0, 0, 1, 1);

        tabWidget_2->addTab(tab_10, QString());
        tab_23 = new QWidget();
        tab_23->setObjectName(QString::fromUtf8("tab_23"));
        Pan_control_bar = new QSlider(tab_23);
        Pan_control_bar->setObjectName(QString::fromUtf8("Pan_control_bar"));
        Pan_control_bar->setGeometry(QRect(70, 200, 160, 29));
        Pan_control_bar->setMinimum(-4480);
        Pan_control_bar->setMaximum(4480);
        Pan_control_bar->setValue(0);
        Pan_control_bar->setOrientation(Qt::Horizontal);
        Tilt_control_bar = new QSlider(tab_23);
        Tilt_control_bar->setObjectName(QString::fromUtf8("Tilt_control_bar"));
        Tilt_control_bar->setGeometry(QRect(140, 20, 29, 160));
        Tilt_control_bar->setMinimum(-1920);
        Tilt_control_bar->setMaximum(1920);
        Tilt_control_bar->setValue(0);
        Tilt_control_bar->setOrientation(Qt::Vertical);
        PanTilt_Reset = new QPushButton(tab_23);
        PanTilt_Reset->setObjectName(QString::fromUtf8("PanTilt_Reset"));
        PanTilt_Reset->setGeometry(QRect(10, 70, 98, 27));
        tabWidget_2->addTab(tab_23, QString());
        tab_26 = new QWidget();
        tab_26->setObjectName(QString::fromUtf8("tab_26"));
        label_42 = new QLabel(tab_26);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setGeometry(QRect(40, 80, 91, 21));
        label_43 = new QLabel(tab_26);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setGeometry(QRect(40, 140, 101, 21));
        left_encoder_value = new QLCDNumber(tab_26);
        left_encoder_value->setObjectName(QString::fromUtf8("left_encoder_value"));
        left_encoder_value->setGeometry(QRect(180, 70, 81, 41));
        right_encoder_value = new QLCDNumber(tab_26);
        right_encoder_value->setObjectName(QString::fromUtf8("right_encoder_value"));
        right_encoder_value->setGeometry(QRect(180, 130, 81, 41));
        tabWidget_2->addTab(tab_26, QString());

        horizontalLayout->addWidget(tabWidget_2);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QString::fromUtf8("tab_6"));
        gridLayout_30 = new QGridLayout(tab_6);
        gridLayout_30->setSpacing(6);
        gridLayout_30->setContentsMargins(11, 11, 11, 11);
        gridLayout_30->setObjectName(QString::fromUtf8("gridLayout_30"));
        gridLayout_19 = new QGridLayout();
        gridLayout_19->setSpacing(6);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        label_20 = new QLabel(tab_6);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_19->addWidget(label_20, 1, 2, 1, 1);

        label_18 = new QLabel(tab_6);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        sizePolicy4.setHeightForWidth(label_18->sizePolicy().hasHeightForWidth());
        label_18->setSizePolicy(sizePolicy4);
        label_18->setMinimumSize(QSize(222, 102));
        label_18->setMaximumSize(QSize(222, 102));
        label_18->setScaledContents(true);

        gridLayout_19->addWidget(label_18, 1, 1, 1, 1);

        progressBar_2 = new QProgressBar(tab_6);
        progressBar_2->setObjectName(QString::fromUtf8("progressBar_2"));
        sizePolicy1.setHeightForWidth(progressBar_2->sizePolicy().hasHeightForWidth());
        progressBar_2->setSizePolicy(sizePolicy1);
        progressBar_2->setMaximumSize(QSize(1677, 70));
        progressBar_2->setLayoutDirection(Qt::LeftToRight);
        progressBar_2->setValue(100);
        progressBar_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        progressBar_2->setTextVisible(true);
        progressBar_2->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(progressBar_2, 2, 1, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));

        gridLayout_19->addLayout(horizontalLayout_3, 0, 1, 1, 1);

        label_33 = new QLabel(tab_6);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        gridLayout_19->addWidget(label_33, 2, 0, 1, 1);

        label_15 = new QLabel(tab_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        sizePolicy4.setHeightForWidth(label_15->sizePolicy().hasHeightForWidth());
        label_15->setSizePolicy(sizePolicy4);
        label_15->setMinimumSize(QSize(52, 52));
        label_15->setMaximumSize(QSize(52, 52));
        label_15->setScaledContents(true);

        gridLayout_19->addWidget(label_15, 1, 0, 1, 1);

        graphicsView_6 = new QGraphicsView(tab_6);
        graphicsView_6->setObjectName(QString::fromUtf8("graphicsView_6"));
        sizePolicy4.setHeightForWidth(graphicsView_6->sizePolicy().hasHeightForWidth());
        graphicsView_6->setSizePolicy(sizePolicy4);
        graphicsView_6->setMinimumSize(QSize(50, 50));
        graphicsView_6->setMaximumSize(QSize(50, 50));

        gridLayout_19->addWidget(graphicsView_6, 3, 1, 1, 1);


        gridLayout_30->addLayout(gridLayout_19, 0, 3, 1, 1);

        graphicsView_7 = new QGraphicsView(tab_6);
        graphicsView_7->setObjectName(QString::fromUtf8("graphicsView_7"));
        sizePolicy1.setHeightForWidth(graphicsView_7->sizePolicy().hasHeightForWidth());
        graphicsView_7->setSizePolicy(sizePolicy1);
        graphicsView_7->setMinimumSize(QSize(0, 0));
        graphicsView_7->setMaximumSize(QSize(230, 230));
        graphicsView_7->setFrameShadow(QFrame::Plain);
        graphicsView_7->setInteractive(true);
        graphicsView_7->setSceneRect(QRectF(0, 0, 0, 0));
        graphicsView_7->setRenderHints(QPainter::Antialiasing|QPainter::SmoothPixmapTransform);
        graphicsView_7->setDragMode(QGraphicsView::ScrollHandDrag);
        graphicsView_7->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_7->setResizeAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_7->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);

        gridLayout_30->addWidget(graphicsView_7, 1, 3, 1, 1);

        camera_2 = new QTabWidget(tab_6);
        camera_2->setObjectName(QString::fromUtf8("camera_2"));
        sizePolicy1.setHeightForWidth(camera_2->sizePolicy().hasHeightForWidth());
        camera_2->setSizePolicy(sizePolicy1);
        camera_2->setFocusPolicy(Qt::NoFocus);
        camera_2->setTabPosition(QTabWidget::North);
        camera_2->setTabShape(QTabWidget::Rounded);
        camera_2->setElideMode(Qt::ElideNone);
        camera_2->setUsesScrollButtons(true);
        tab_19 = new QWidget();
        tab_19->setObjectName(QString::fromUtf8("tab_19"));
        gridLayout_32 = new QGridLayout(tab_19);
        gridLayout_32->setSpacing(6);
        gridLayout_32->setContentsMargins(11, 11, 11, 11);
        gridLayout_32->setObjectName(QString::fromUtf8("gridLayout_32"));
        graphicsView_13 = new QGraphicsView(tab_19);
        graphicsView_13->setObjectName(QString::fromUtf8("graphicsView_13"));
        sizePolicy1.setHeightForWidth(graphicsView_13->sizePolicy().hasHeightForWidth());
        graphicsView_13->setSizePolicy(sizePolicy1);
        graphicsView_13->setMaximumSize(QSize(643, 483));
        graphicsView_13->setFocusPolicy(Qt::NoFocus);
        graphicsView_13->setFrameShadow(QFrame::Plain);
        graphicsView_13->setInteractive(true);
        graphicsView_13->setSceneRect(QRectF(0, 0, 0, 0));
        graphicsView_13->setRenderHints(QPainter::Antialiasing|QPainter::SmoothPixmapTransform);
        graphicsView_13->setDragMode(QGraphicsView::ScrollHandDrag);
        graphicsView_13->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_13->setResizeAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView_13->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);

        gridLayout_32->addWidget(graphicsView_13, 0, 0, 1, 1);

        camera_2->addTab(tab_19, QString());
        cameraPage1_2 = new QWidget();
        cameraPage1_2->setObjectName(QString::fromUtf8("cameraPage1_2"));
        gridLayout_7 = new QGridLayout(cameraPage1_2);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        graphicsView_14 = new QGraphicsView(cameraPage1_2);
        graphicsView_14->setObjectName(QString::fromUtf8("graphicsView_14"));
        sizePolicy1.setHeightForWidth(graphicsView_14->sizePolicy().hasHeightForWidth());
        graphicsView_14->setSizePolicy(sizePolicy1);
        graphicsView_14->setMaximumSize(QSize(643, 483));
        graphicsView_14->setFocusPolicy(Qt::NoFocus);

        gridLayout_7->addWidget(graphicsView_14, 0, 0, 1, 1);

        verticalScrollBar_3 = new QScrollBar(cameraPage1_2);
        verticalScrollBar_3->setObjectName(QString::fromUtf8("verticalScrollBar_3"));
        verticalScrollBar_3->setMinimum(-1920);
        verticalScrollBar_3->setMaximum(1408);
        verticalScrollBar_3->setOrientation(Qt::Vertical);

        gridLayout_7->addWidget(verticalScrollBar_3, 0, 1, 1, 1);

        horizontalScrollBar_3 = new QScrollBar(cameraPage1_2);
        horizontalScrollBar_3->setObjectName(QString::fromUtf8("horizontalScrollBar_3"));
        horizontalScrollBar_3->setMinimum(-4480);
        horizontalScrollBar_3->setMaximum(4480);
        horizontalScrollBar_3->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(horizontalScrollBar_3, 1, 0, 1, 1);

        camera_2->addTab(cameraPage1_2, QString());
        tab_22 = new QWidget();
        tab_22->setObjectName(QString::fromUtf8("tab_22"));
        gridLayout_33 = new QGridLayout(tab_22);
        gridLayout_33->setSpacing(6);
        gridLayout_33->setContentsMargins(11, 11, 11, 11);
        gridLayout_33->setObjectName(QString::fromUtf8("gridLayout_33"));
        graphicsView_15 = new QGraphicsView(tab_22);
        graphicsView_15->setObjectName(QString::fromUtf8("graphicsView_15"));
        sizePolicy1.setHeightForWidth(graphicsView_15->sizePolicy().hasHeightForWidth());
        graphicsView_15->setSizePolicy(sizePolicy1);
        graphicsView_15->setMaximumSize(QSize(643, 483));
        graphicsView_15->setFocusPolicy(Qt::NoFocus);

        gridLayout_33->addWidget(graphicsView_15, 0, 0, 1, 1);

        camera_2->addTab(tab_22, QString());
        tab_24 = new QWidget();
        tab_24->setObjectName(QString::fromUtf8("tab_24"));
        gridLayout_34 = new QGridLayout(tab_24);
        gridLayout_34->setSpacing(6);
        gridLayout_34->setContentsMargins(11, 11, 11, 11);
        gridLayout_34->setObjectName(QString::fromUtf8("gridLayout_34"));
        graphicsView_16 = new QGraphicsView(tab_24);
        graphicsView_16->setObjectName(QString::fromUtf8("graphicsView_16"));
        sizePolicy1.setHeightForWidth(graphicsView_16->sizePolicy().hasHeightForWidth());
        graphicsView_16->setSizePolicy(sizePolicy1);
        graphicsView_16->setMaximumSize(QSize(643, 483));
        graphicsView_16->setFocusPolicy(Qt::NoFocus);

        gridLayout_34->addWidget(graphicsView_16, 0, 0, 1, 1);

        camera_2->addTab(tab_24, QString());

        gridLayout_30->addWidget(camera_2, 0, 2, 2, 1);

        tabWidget->addTab(tab_6, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout_16 = new QGridLayout(tab_2);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        webView = new QWebView(tab_2);
        webView->setObjectName(QString::fromUtf8("webView"));
        sizePolicy1.setHeightForWidth(webView->sizePolicy().hasHeightForWidth());
        webView->setSizePolicy(sizePolicy1);
        webView->setMaximumSize(QSize(640, 16777215));
        webView->setMouseTracking(true);
        webView->setFocusPolicy(Qt::NoFocus);
        webView->setLayoutDirection(Qt::LeftToRight);
        webView->setUrl(QUrl("http://maps.google.com/maps/api/staticmap?size=1200x440&maptype=roadmap&sensor=false"));
        webView->setZoomFactor(1);

        gridLayout_16->addWidget(webView, 0, 0, 3, 1);

        listWidget = new QListWidget(tab_2);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        gridLayout_16->addWidget(listWidget, 2, 2, 1, 1);

        gridLayout_18 = new QGridLayout();
        gridLayout_18->setSpacing(6);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        label_16 = new QLabel(tab_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_18->addWidget(label_16, 1, 1, 1, 1);

        lcdNumber_4 = new QLCDNumber(tab_2);
        lcdNumber_4->setObjectName(QString::fromUtf8("lcdNumber_4"));
        lcdNumber_4->setLineWidth(0);

        gridLayout_18->addWidget(lcdNumber_4, 1, 5, 1, 1);

        label_17 = new QLabel(tab_2);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setLayoutDirection(Qt::LeftToRight);
        label_17->setAutoFillBackground(false);
        label_17->setScaledContents(false);
        label_17->setMargin(0);
        label_17->setOpenExternalLinks(false);

        gridLayout_18->addWidget(label_17, 2, 1, 1, 1);

        lcdNumber_5 = new QLCDNumber(tab_2);
        lcdNumber_5->setObjectName(QString::fromUtf8("lcdNumber_5"));
        lcdNumber_5->setLineWidth(0);

        gridLayout_18->addWidget(lcdNumber_5, 2, 5, 1, 1);

        label_9 = new QLabel(tab_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_18->addWidget(label_9, 3, 1, 1, 1);

        spinBox = new QSpinBox(tab_2);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));

        gridLayout_18->addWidget(spinBox, 3, 5, 1, 1);

        label_37 = new QLabel(tab_2);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        gridLayout_18->addWidget(label_37, 4, 1, 1, 1);

        comboBox = new QComboBox(tab_2);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        gridLayout_18->addWidget(comboBox, 4, 5, 1, 1);

        label_38 = new QLabel(tab_2);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        gridLayout_18->addWidget(label_38, 5, 1, 1, 1);

        spinBox_2 = new QSpinBox(tab_2);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));

        gridLayout_18->addWidget(spinBox_2, 5, 5, 1, 1);

        start_gps = new QPushButton(tab_2);
        start_gps->setObjectName(QString::fromUtf8("start_gps"));
        sizePolicy4.setHeightForWidth(start_gps->sizePolicy().hasHeightForWidth());
        start_gps->setSizePolicy(sizePolicy4);
        start_gps->setMinimumSize(QSize(114, 0));
        start_gps->setMaximumSize(QSize(114, 16777215));

        gridLayout_18->addWidget(start_gps, 6, 1, 1, 1);

        sto_gps = new QPushButton(tab_2);
        sto_gps->setObjectName(QString::fromUtf8("sto_gps"));
        sizePolicy4.setHeightForWidth(sto_gps->sizePolicy().hasHeightForWidth());
        sto_gps->setSizePolicy(sizePolicy4);
        sto_gps->setMinimumSize(QSize(114, 0));
        sto_gps->setMaximumSize(QSize(114, 16777215));

        gridLayout_18->addWidget(sto_gps, 6, 5, 1, 1);

        load_gps = new QPushButton(tab_2);
        load_gps->setObjectName(QString::fromUtf8("load_gps"));
        sizePolicy4.setHeightForWidth(load_gps->sizePolicy().hasHeightForWidth());
        load_gps->setSizePolicy(sizePolicy4);

        gridLayout_18->addWidget(load_gps, 7, 5, 1, 1);

        save_gps = new QPushButton(tab_2);
        save_gps->setObjectName(QString::fromUtf8("save_gps"));
        sizePolicy4.setHeightForWidth(save_gps->sizePolicy().hasHeightForWidth());
        save_gps->setSizePolicy(sizePolicy4);
        save_gps->setMinimumSize(QSize(114, 0));
        save_gps->setMaximumSize(QSize(114, 16777215));

        gridLayout_18->addWidget(save_gps, 7, 1, 1, 1);


        gridLayout_16->addLayout(gridLayout_18, 0, 2, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        gridLayout_21 = new QGridLayout(tab_4);
        gridLayout_21->setSpacing(6);
        gridLayout_21->setContentsMargins(11, 11, 11, 11);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        tabWidget_3 = new QTabWidget(tab_4);
        tabWidget_3->setObjectName(QString::fromUtf8("tabWidget_3"));
        tab_15 = new QWidget();
        tab_15->setObjectName(QString::fromUtf8("tab_15"));
        gridLayout_22 = new QGridLayout(tab_15);
        gridLayout_22->setSpacing(6);
        gridLayout_22->setContentsMargins(11, 11, 11, 11);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        graphicsView_8 = new QGraphicsView(tab_15);
        graphicsView_8->setObjectName(QString::fromUtf8("graphicsView_8"));
        sizePolicy5.setHeightForWidth(graphicsView_8->sizePolicy().hasHeightForWidth());
        graphicsView_8->setSizePolicy(sizePolicy5);
        graphicsView_8->setMaximumSize(QSize(430, 315));

        gridLayout_22->addWidget(graphicsView_8, 0, 0, 1, 1);

        tabWidget_3->addTab(tab_15, QString());

        gridLayout_21->addWidget(tabWidget_3, 0, 0, 4, 1);

        tabWidget_4 = new QTabWidget(tab_4);
        tabWidget_4->setObjectName(QString::fromUtf8("tabWidget_4"));
        tab_17 = new QWidget();
        tab_17->setObjectName(QString::fromUtf8("tab_17"));
        gridLayout_23 = new QGridLayout(tab_17);
        gridLayout_23->setSpacing(6);
        gridLayout_23->setContentsMargins(11, 11, 11, 11);
        gridLayout_23->setObjectName(QString::fromUtf8("gridLayout_23"));
        graphicsView_9 = new QGraphicsView(tab_17);
        graphicsView_9->setObjectName(QString::fromUtf8("graphicsView_9"));
        sizePolicy1.setHeightForWidth(graphicsView_9->sizePolicy().hasHeightForWidth());
        graphicsView_9->setSizePolicy(sizePolicy1);
        graphicsView_9->setMaximumSize(QSize(430, 315));

        gridLayout_23->addWidget(graphicsView_9, 0, 0, 1, 1);

        tabWidget_4->addTab(tab_17, QString());

        gridLayout_21->addWidget(tabWidget_4, 2, 1, 1, 1);

        tabWidget_6 = new QTabWidget(tab_4);
        tabWidget_6->setObjectName(QString::fromUtf8("tabWidget_6"));
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        gridLayout_27 = new QGridLayout(tab_3);
        gridLayout_27->setSpacing(6);
        gridLayout_27->setContentsMargins(11, 11, 11, 11);
        gridLayout_27->setObjectName(QString::fromUtf8("gridLayout_27"));
        textBrowser = new QTextBrowser(tab_3);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        sizePolicy3.setHeightForWidth(textBrowser->sizePolicy().hasHeightForWidth());
        textBrowser->setSizePolicy(sizePolicy3);

        gridLayout_27->addWidget(textBrowser, 0, 0, 1, 1);

        tabWidget_6->addTab(tab_3, QString());
        tab_18 = new QWidget();
        tab_18->setObjectName(QString::fromUtf8("tab_18"));
        gridLayout_29 = new QGridLayout(tab_18);
        gridLayout_29->setSpacing(6);
        gridLayout_29->setContentsMargins(11, 11, 11, 11);
        gridLayout_29->setObjectName(QString::fromUtf8("gridLayout_29"));
        radioButton_11 = new QRadioButton(tab_18);
        radioButton_11->setObjectName(QString::fromUtf8("radioButton_11"));

        gridLayout_29->addWidget(radioButton_11, 3, 1, 1, 1);

        radioButton_12 = new QRadioButton(tab_18);
        radioButton_12->setObjectName(QString::fromUtf8("radioButton_12"));

        gridLayout_29->addWidget(radioButton_12, 3, 0, 1, 1);

        checkBox = new QCheckBox(tab_18);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout_29->addWidget(checkBox, 0, 0, 1, 1);

        tabWidget_6->addTab(tab_18, QString());

        gridLayout_21->addWidget(tabWidget_6, 0, 1, 1, 1);

        tabWidget->addTab(tab_4, QString());

        gridLayout_2->addWidget(tabWidget, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1458, 25));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);
        tabWidget_5->setCurrentIndex(0);
        tabWidget_8->setCurrentIndex(0);
        DeviceAttached->setCurrentIndex(0);
        arm->setCurrentIndex(0);
        camera->setCurrentIndex(5);
        drive->setCurrentIndex(1);
        tabWidget_2->setCurrentIndex(3);
        camera_2->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(0);
        tabWidget_6->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Corobot-Remote Control Interface", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("MainWindow", "Master URL:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        Master->setToolTip(QApplication::translate("MainWindow", "Address Ip or Url of the robot", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_39->setText(QApplication::translate("MainWindow", "Host IP:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        Host->setToolTip(QApplication::translate("MainWindow", "Adress IP of this machine.", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        connect->setText(QApplication::translate("MainWindow", "Connect", 0, QApplication::UnicodeUTF8));
        environmentcheckbox->setText(QApplication::translate("MainWindow", "Environment variables", 0, QApplication::UnicodeUTF8));
        tabWidget_5->setTabText(tabWidget_5->indexOf(widget), QApplication::translate("MainWindow", "Connection", 0, QApplication::UnicodeUTF8));
        tabWidget_5->setTabToolTip(tabWidget_5->indexOf(widget), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Configure the connection to the ROS server, on the robot. If the Remote control interface is on the robot, you can just check Environment variables.</p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Click connect to connect to the server. </p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This is necessary for the remote control to work.</p></body></html>", 0, QApplication::UnicodeUTF8));
        radioButton_9->setText(QApplication::translate("MainWindow", "Corobot", 0, QApplication::UnicodeUTF8));
        radioButton_10->setText(QApplication::translate("MainWindow", "Explorer", 0, QApplication::UnicodeUTF8));
        tabWidget_8->setTabText(tabWidget_8->indexOf(Select), QApplication::translate("MainWindow", "Robot", 0, QApplication::UnicodeUTF8));
        tabWidget_8->setTabToolTip(tabWidget_8->indexOf(Select), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Select the robot you are using.</p></body></html>", 0, QApplication::UnicodeUTF8));
        DeviceAttached->setTabText(DeviceAttached->indexOf(tab_27), QApplication::translate("MainWindow", "Device attached Info", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_41->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Do you have a kinect on the robot?</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_41->setText(QApplication::translate("MainWindow", "Kinect:", 0, QApplication::UnicodeUTF8));
        checkBox_2->setText(QString());
        DeviceAttached->setTabText(DeviceAttached->indexOf(tab_20), QApplication::translate("MainWindow", "Cameras", 0, QApplication::UnicodeUTF8));
        DeviceAttached->setTabToolTip(DeviceAttached->indexOf(tab_20), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">COnfigure everything about the cameras</p></body></html>", 0, QApplication::UnicodeUTF8));
        quitButton->setText(QApplication::translate("MainWindow", "Quit", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "Configuration", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabToolTip(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Configuration tab</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        arm->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        arm->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
#ifndef QT_NO_WHATSTHIS
        arm->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        arm->setAccessibleName(QString());
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        arm->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_TOOLTIP
        label_3->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Angle between the upper arm and the robot </p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_3->setText(QApplication::translate("MainWindow", "Shoulder angle:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_5->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the Shoulder angle in degree</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_5->setText(QApplication::translate("MainWindow", "degree", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_6->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the shoulder angle in radian</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_6->setText(QApplication::translate("MainWindow", "radian   ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_4->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Angle between the upper and the lower arm</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_4->setText(QApplication::translate("MainWindow", "   Elbow angle:    ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_8->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the elbow angle in radian</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_8->setText(QApplication::translate("MainWindow", "radian", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_7->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the elbow angle in degree</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_7->setText(QApplication::translate("MainWindow", "degree", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        frame->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This is a representation of the actual arm on the robot. You can grab the end effector with your mouse to make the amr move.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        arm->setTabText(arm->indexOf(armPage1), QApplication::translate("MainWindow", "Arm", 0, QApplication::UnicodeUTF8));
        arm->setTabToolTip(arm->indexOf(armPage1), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">This tab enables the user to moves the robot arm thanks to his mouse. You can move the end effector on the drawing by clicking on it and moving your mouse.</span></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton->setToolTip(QApplication::translate("MainWindow", "Open the gripper", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton->setText(QApplication::translate("MainWindow", "Open", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        frame_7->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Here you can see the state of the Gripper</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_5->setText(QString());
#ifndef QT_NO_TOOLTIP
        radioButton_2->setToolTip(QApplication::translate("MainWindow", "close the gripper", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_2->setText(QApplication::translate("MainWindow", "Close", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/gripper.jpg\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        frame_8->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Representation of the orientation of the wrist. You can click with your mouse on the long red line and move your mouse to move the line to change the orientation.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_11->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/wrist.jpg\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_4->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the wrist angle in radian</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_4->setText(QApplication::translate("MainWindow", "radian", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        radioButton_3->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the wrist angle in degree</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        radioButton_3->setText(QApplication::translate("MainWindow", "degree", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("MainWindow", "Wrist angle:", 0, QApplication::UnicodeUTF8));
        label_8->setText(QString());
        arm->setTabText(arm->indexOf(tab_11), QApplication::translate("MainWindow", "Wrist and Gripper", 0, QApplication::UnicodeUTF8));
        arm->setTabToolTip(arm->indexOf(tab_11), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This tab elables the user to see and modify the orientation of the wrist and the state of the gripper(open/close).</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        camera->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        graphicsView_4->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display all cameras that can be found on the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera->setTabText(camera->indexOf(tab_9), QApplication::translate("MainWindow", "all camera", 0, QApplication::UnicodeUTF8));
        camera->setTabToolTip(camera->indexOf(tab_9), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display all cameras that can be found on the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
        camera->setTabWhatsThis(camera->indexOf(tab_9), QApplication::translate("MainWindow", "SZGER", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView->setToolTip(QApplication::translate("MainWindow", "Display the robot's hd camera ", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera->setTabText(camera->indexOf(cameraPage1), QApplication::translate("MainWindow", "PTZ camera", 0, QApplication::UnicodeUTF8));
        camera->setTabToolTip(camera->indexOf(cameraPage1), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the robot's hd camera </p></body></html>", 0, QApplication::UnicodeUTF8));
        camera->setTabText(camera->indexOf(tab_16), QApplication::translate("MainWindow", "Rear Cam", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_2->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the RGB camera from the kinect</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera->setTabText(camera->indexOf(tab_7), QApplication::translate("MainWindow", "Kinect Camera", 0, QApplication::UnicodeUTF8));
        camera->setTabToolTip(camera->indexOf(tab_7), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the RGB camera from the kinect</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_3->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the kinect depth image </p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera->setTabText(camera->indexOf(tab_8), QApplication::translate("MainWindow", "Depth camera", 0, QApplication::UnicodeUTF8));
        camera->setTabToolTip(camera->indexOf(tab_8), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the kinect depth image </p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_5->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the infrared data</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera->setTabText(camera->indexOf(tab_21), QApplication::translate("MainWindow", "Spatial view", 0, QApplication::UnicodeUTF8));
        camera->setTabToolTip(camera->indexOf(tab_21), QApplication::translate("MainWindow", "Display the infrared data", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        drive->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">keyboard</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/keyboard.png\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_2->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Joystick</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_2->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/Joystick.png\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_21->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">mouse</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_21->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/mouse.jpg\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
        drive->setTabText(drive->indexOf(drivePage1), QApplication::translate("MainWindow", "drive methods", 0, QApplication::UnicodeUTF8));
        drive->setTabToolTip(drive->indexOf(drivePage1), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display all the methods that permits to drive the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_22->setText(QApplication::translate("MainWindow", "Linear Speed:", 0, QApplication::UnicodeUTF8));
        label_23->setText(QApplication::translate("MainWindow", "FWD", 0, QApplication::UnicodeUTF8));
        label_25->setText(QApplication::translate("MainWindow", "Angular Speed", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        horizontalSlider->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Lucida Grande'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Moving the button on the left makes the robot turning left. </p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Moving it on the right makes the robot turning right</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        verticalSlider->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Lucida Grande'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Moving the button on the top makes the robot moving forward.</p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Moving it on the bottom makes the robot moving backward.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        lcdNumber_6->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">percentage of the maximum linear speed</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_34->setText(QApplication::translate("MainWindow", "%", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        lcdNumber_7->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">percentage of the maximum angular speed</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_35->setText(QApplication::translate("MainWindow", "%", 0, QApplication::UnicodeUTF8));
        drive->setTabText(drive->indexOf(tab_13), QApplication::translate("MainWindow", "mouse drive", 0, QApplication::UnicodeUTF8));
        drive->setTabToolTip(drive->indexOf(tab_13), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Drive the robot with the mouse</p></body></html>", 0, QApplication::UnicodeUTF8));
        Forward->setText(QApplication::translate("MainWindow", "F", 0, QApplication::UnicodeUTF8));
        TURNLEFT->setText(QApplication::translate("MainWindow", "L", 0, QApplication::UnicodeUTF8));
        STOP->setText(QApplication::translate("MainWindow", "STOP", 0, QApplication::UnicodeUTF8));
        TURNRIGHT->setText(QApplication::translate("MainWindow", "R", 0, QApplication::UnicodeUTF8));
        BACKWARD->setText(QApplication::translate("MainWindow", "B", 0, QApplication::UnicodeUTF8));
        label_44->setText(QApplication::translate("MainWindow", "Move Speed", 0, QApplication::UnicodeUTF8));
        label_45->setText(QApplication::translate("MainWindow", "Turning Speed", 0, QApplication::UnicodeUTF8));
        drive->setTabText(drive->indexOf(tab_25), QApplication::translate("MainWindow", "Robot Drive", 0, QApplication::UnicodeUTF8));
        label_13->setText(QString());
        label_14->setText(QApplication::translate("MainWindow", "Voltage:", 0, QApplication::UnicodeUTF8));
        label_36->setText(QApplication::translate("MainWindow", "V", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        progressBar->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Percentage of battery left</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_12), QApplication::translate("MainWindow", "Battery", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabToolTip(tabWidget_2->indexOf(tab_12), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display some battery information</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_27->setText(QApplication::translate("MainWindow", "Internal Temperature", 0, QApplication::UnicodeUTF8));
        label_28->setText(QApplication::translate("MainWindow", "CPU", 0, QApplication::UnicodeUTF8));
        label_29->setText(QApplication::translate("MainWindow", "Base", 0, QApplication::UnicodeUTF8));
        label_30->setText(QApplication::translate("MainWindow", "External Temperature", 0, QApplication::UnicodeUTF8));
        label_31->setText(QApplication::translate("MainWindow", "Humidity", 0, QApplication::UnicodeUTF8));
        label_32->setText(QApplication::translate("MainWindow", "Light", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_14), QApplication::translate("MainWindow", "Misc Data", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabToolTip(tabWidget_2->indexOf(tab_14), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display some sensors value</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_24->setText(QApplication::translate("MainWindow", "          Bumper2", 0, QApplication::UnicodeUTF8));
        label_26->setText(QApplication::translate("MainWindow", "        Bumper3", 0, QApplication::UnicodeUTF8));
        label_40->setText(QApplication::translate("MainWindow", "         Bumper4", 0, QApplication::UnicodeUTF8));
        label_19->setText(QApplication::translate("MainWindow", "         Bumper1", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_10), QApplication::translate("MainWindow", "Bumpers", 0, QApplication::UnicodeUTF8));
        PanTilt_Reset->setText(QApplication::translate("MainWindow", "Reset", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_23), QApplication::translate("MainWindow", "Pan/Tilt Control", 0, QApplication::UnicodeUTF8));
        label_42->setText(QApplication::translate("MainWindow", "Left Encoder", 0, QApplication::UnicodeUTF8));
        label_43->setText(QApplication::translate("MainWindow", "Right Encoder", 0, QApplication::UnicodeUTF8));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_26), QApplication::translate("MainWindow", "Odometry Data", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "engineering control", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabToolTip(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This tab enables the user to control the robot and to access a lot of information regarding the robot : sensors value, camera... and</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_20->setText(QString());
#ifndef QT_NO_TOOLTIP
        label_18->setToolTip(QApplication::translate("MainWindow", "keyboard", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_18->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/keyboard.png\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        progressBar_2->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Percentage of battery left</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_33->setText(QApplication::translate("MainWindow", "Battery", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_15->setToolTip(QApplication::translate("MainWindow", "Joystick", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_15->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/qresource/Joystick.png\" /></p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_6->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Representation of the robot arm. The bigger the circle is, the closer the end effector is from the robot. The vertical movement of the circle represents the  vertical movement of the arm</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        graphicsView_7->setToolTip(QApplication::translate("MainWindow", "Display the infrared data", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        graphicsView_13->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display all cameras that can be found on the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera_2->setTabText(camera_2->indexOf(tab_19), QApplication::translate("MainWindow", "all camera", 0, QApplication::UnicodeUTF8));
        camera_2->setTabToolTip(camera_2->indexOf(tab_19), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display all cameras that can be found on the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
        camera_2->setTabWhatsThis(camera_2->indexOf(tab_19), QApplication::translate("MainWindow", "SZGER", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_14->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the robot's hd camera </p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera_2->setTabText(camera_2->indexOf(cameraPage1_2), QApplication::translate("MainWindow", "HD camera", 0, QApplication::UnicodeUTF8));
        camera_2->setTabToolTip(camera_2->indexOf(cameraPage1_2), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the robot's hd camera </p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_15->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the RGB camera from the kinect</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera_2->setTabText(camera_2->indexOf(tab_22), QApplication::translate("MainWindow", "Kinect Camera", 0, QApplication::UnicodeUTF8));
        camera_2->setTabToolTip(camera_2->indexOf(tab_22), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the RGB camera from the kinect</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_16->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the kinect depth image </p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        camera_2->setTabText(camera_2->indexOf(tab_24), QApplication::translate("MainWindow", "Depth camera", 0, QApplication::UnicodeUTF8));
        camera_2->setTabToolTip(camera_2->indexOf(tab_24), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the kinect depth image </p></body></html>", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("MainWindow", "field control", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabToolTip(tabWidget->indexOf(tab_6), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This tab enables the user to control the robot and to access the minimum information required to control the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        webView->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Map that show the position of the robot and the path of the selected itinerary.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        listWidget->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">List of all loaded itineraries.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label_16->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the longitude position of the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_16->setText(QApplication::translate("MainWindow", "                      Longitude: ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        lcdNumber_4->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the longitude position of the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label_17->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the latitude position of the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_17->setText(QApplication::translate("MainWindow", "                         Latitude:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        lcdNumber_5->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the latitude position of the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label_9->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Select the sampling frequency value of the gps data</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_9->setText(QApplication::translate("MainWindow", "        sampling frequency:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        spinBox->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Select the sampling frequency value of the gps data</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label_37->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Select the map type</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_37->setText(QApplication::translate("MainWindow", "                        map type:", 0, QApplication::UnicodeUTF8));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "roadmap", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "satellite", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "terrain", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "hybrid", 0, QApplication::UnicodeUTF8)
        );
#ifndef QT_NO_TOOLTIP
        comboBox->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Select the map type</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        label_38->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">choose the value of the zoom in the map. 0 is an automatic zoom.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_38->setText(QApplication::translate("MainWindow", "                             zoom:", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        spinBox_2->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">choose the value of the zoom in the map. 0 is an automatic zoom.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        start_gps->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Start a new itinierary. The path will be shown on the map. It will delete the last itinerary made if unsaved.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        start_gps->setText(QApplication::translate("MainWindow", "Start Itinenary ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        sto_gps->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Stop the running itinerary</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        sto_gps->setText(QApplication::translate("MainWindow", "Stop Itinerary", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        load_gps->setToolTip(QApplication::translate("MainWindow", "Load from the hard drive an itinerary previously saved.", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        load_gps->setText(QApplication::translate("MainWindow", "Load Itinerary", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        save_gps->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Save on the hard drive the last itinerary stoped. </p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        save_gps->setText(QApplication::translate("MainWindow", "Save Itinerary", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "GPS", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabToolTip(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This tab shows the GPS position of the robot and show a map of it. You can also save and view the itinerary of the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_8->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the camera coming from the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_15), QApplication::translate("MainWindow", "Robot Camera", 0, QApplication::UnicodeUTF8));
        tabWidget_3->setTabToolTip(tabWidget_3->indexOf(tab_15), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the camera coming from the robot</p></body></html>", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        graphicsView_9->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Display the image coming from the running kinect.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_17), QApplication::translate("MainWindow", "Computer kinect", 0, QApplication::UnicodeUTF8));
        tabWidget_4->setTabToolTip(tabWidget_4->indexOf(tab_17), QApplication::translate("MainWindow", "Display the image coming from the running kinect.", 0, QApplication::UnicodeUTF8));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<table border=\"0\" style=\"-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;\">\n"
"<tr>\n"
"<td style=\"border: none;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:10pt;\">Control the robot using a kinect on your computer. </span></p>\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:10pt;\"></p>\n"
"<p align=\"justify\" style=\" marg"
                        "in-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:10pt;\">Show both hands at the camera. Moving your right hand vertically changes the speed, moving it horizontally changes the angular speed.</span></p>\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:10pt;\"></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:10pt;\">Moving your left hand vertically moves the robot arm vertically, moving your hand horizontally moves the robot arm in the same way. Moving your hands toward you moves the arm toward the robot. </span></p>\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-"
                        "bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:10pt;\"></p></td></tr></table></body></html>", 0, QApplication::UnicodeUTF8));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_3), QApplication::translate("MainWindow", "Explanation", 0, QApplication::UnicodeUTF8));
        tabWidget_6->setTabToolTip(tabWidget_6->indexOf(tab_3), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Explain how to control the robot with your kinect</p></body></html>", 0, QApplication::UnicodeUTF8));
        radioButton_11->setText(QApplication::translate("MainWindow", "Right Handed", 0, QApplication::UnicodeUTF8));
        radioButton_12->setText(QApplication::translate("MainWindow", "Left Handed", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        checkBox->setToolTip(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Choose to control the arm or not. Only available with a Corobot.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        checkBox->setText(QApplication::translate("MainWindow", "arm control", 0, QApplication::UnicodeUTF8));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_18), QApplication::translate("MainWindow", "Configuration", 0, QApplication::UnicodeUTF8));
        tabWidget_6->setTabToolTip(tabWidget_6->indexOf(tab_18), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Configure the controls</p></body></html>", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "kinect communication", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabToolTip(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This tab enables the user to control the robot thanks to a kinect.</p></body></html>", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

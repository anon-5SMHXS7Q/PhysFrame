# parrot_arsdk

This is a [catkin](http://wiki.ros.org/catkin) wrapper for the [official Parrot ARSDK3](https://github.com/Parrot-Developers/arsdk_manifests).

## Build status

[![Build Status](https://travis-ci.org/AutonomyLab/parrot_arsdk.svg?branch=indigo-devel)](https://travis-ci.org/AutonomyLab/parrot_arsdk)


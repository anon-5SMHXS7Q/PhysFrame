The contents of this folder are NOT checked into the git repo because they are multiple megabytes in size. They *do* exist on the Olin network at Sandbox/IARC/bags

Code in the repository should not depend on the existence of files in the folder, given that they may not exist on everyone's machines.

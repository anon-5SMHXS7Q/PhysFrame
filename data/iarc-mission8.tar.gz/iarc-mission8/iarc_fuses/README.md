# IARC-Fuses

Fused Sensory Enhancement for IARC Mission 8.

## HUD Demo

![hud](figs/hud.gif)

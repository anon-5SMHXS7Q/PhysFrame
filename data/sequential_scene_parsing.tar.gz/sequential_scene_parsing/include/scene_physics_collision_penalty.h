#ifndef SCENE_PHYSICS_COLLSION_PENALTY_H
#define SCENE_PHYSICS_COLLSION_PENALTY_H

#include <vector>
#include <cmath>

#include <btBulletDynamicsCommon.h>

#include "physics_world_parameters.h"



#endif
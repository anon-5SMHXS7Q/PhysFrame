# contamination_monitor
This package models the two-dimensional spread of bacteria, viruses, or other contaminated particles around a room. 

It utilizes the people tracking package. 

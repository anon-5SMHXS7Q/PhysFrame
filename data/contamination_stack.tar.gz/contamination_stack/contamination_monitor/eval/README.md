This directory contains scripts/files to evaluate the accuracy of the contamination tracking and monitoring system.

It is not indended for general use.

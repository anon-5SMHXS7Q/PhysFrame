### People Tracking ###
Tested on: ROS Indigo

This package allows for tracking multipeople in a space via a wall mounted laser. 

The code currently assumes a SICK PLS 101-112 laser scanner. 

This package requires there to be a previous map and transform from the map to the laser to be able to display the tracked persons in the map.


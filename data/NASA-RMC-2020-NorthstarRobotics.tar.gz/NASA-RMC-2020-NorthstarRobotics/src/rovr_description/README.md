From this directory, run the following to visualize the URDF in rviz:

```
roslaunch urdf_tutorial display.launch model:=urdf/rovr.urdf.xacro
```

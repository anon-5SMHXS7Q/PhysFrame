// Convert from cmd_vel to 4 wheel commands

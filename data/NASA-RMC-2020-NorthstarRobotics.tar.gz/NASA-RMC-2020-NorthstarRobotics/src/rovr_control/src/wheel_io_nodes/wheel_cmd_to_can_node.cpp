// Set of four wheel cmds to can msg

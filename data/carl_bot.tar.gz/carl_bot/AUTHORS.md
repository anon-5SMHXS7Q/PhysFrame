Original Authors
----------------

 * [Russell Toris](https://github.com/rctoris/) (russell.toris@gmail.com)
 * [David Kent](davidkent@wpi.edu)
 * [Chris Dunkers](cmdunkers@wpi.edu)
 * [Steven Kordell](spkordell@wpi.edu)

Contributors
------------

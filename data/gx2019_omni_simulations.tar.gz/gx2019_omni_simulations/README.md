<!--
 * @Author: your name
 * @Date: 2019-11-05 21:41:24
 * @LastEditTime: 2019-11-05 21:47:12
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /gx2019_omni_simulations/README.md
 -->
# gx2019_omni_simulations

|Author|@lifuguan , @Wacokgde , @Yanwu Chen|
|---|---
|ROS|melodic
|Compute platform| Intel Core I3-7100U|date 2019.11.3

![Our car.](img/car.jpg)
![Our car.](img/car2.jpg)
![Our car.](img/car3.jpg)

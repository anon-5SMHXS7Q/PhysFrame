/*****************************************************/
/* BEFORE RUNNING ROS TYPE "sudo -s" IN THE TERMINAL */
/*****************************************************/

#include <ros/ros.h>            // Most common public pieces of the ROS system
#include <std_msgs/UInt8.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
#include <signal.h> // To catch ctrl-c
#include "../include/i2c/i2c.h"

#define RESET   "\033[0m"
#define RED	"\u001b[31m"	/* Red */
#define CYAN    "\033[36m"      /* Cyan */
#define YELLOW  "\u001b[33m"	/* Yellow */

void signal_callback_handler(int signum);	
void i2c_msgCallback_left(const std_msgs::UInt8& msg);
void i2c_msgCallback_right(const std_msgs::UInt8& msg);
void init_device(I2CDevice* device, unsigned short addr, int fd);
bool rx_data(const I2CDevice *device, unsigned int iaddr, void *buf, size_t len);
bool tx_data(const I2CDevice *device, unsigned int iaddr, void *buf, size_t len);
void verify_data(I2CDevice* device, bool was_rx_succ, bool was_tx_succ, unsigned char* data_write, unsigned char* data_read);
void print_data(unsigned char* data_write_1,unsigned char* data_read_1,unsigned char* data_write_2,unsigned char* data_read_2,
		   bool was_PIC1_tx_succ,bool was_PIC1_rx_succ,bool was_PIC2_tx_succ,bool was_PIC2_rx_succ);
void print_num_error(bool read_1, bool read_2, bool write_1, bool write_2, unsigned int loops_to_analyze);

unsigned short const addr_1 = 0x19;
unsigned short const addr_2 = 0x1B;

std_msgs::UInt8 ref_left; // RPM - from Navigation algorithm
std_msgs::UInt8 ref_right;
std_msgs::UInt8 speed_left; // RPM - from PICs
std_msgs::UInt8 speed_right;
ros::Time current_time;
ros::Time last_time;
int fd; // BUS
unsigned int loop_counter = 0;
unsigned int num_error_read  = 0;
unsigned int num_error_write = 0;

int main(int argc, char **argv)
{
//////////////////////////////////////////////////////////////////////////// ROS SETUP
    ros::init(argc, argv, "i2c_handler");
    ros::NodeHandle nodeHandle;
    current_time = ros::Time::now();
    last_time    = ros::Time::now();

    ros::Publisher publisher_left  = nodeHandle.advertise<std_msgs::UInt8>("speed_left", 1); // Message of speed
    ros::Publisher publisher_right = nodeHandle.advertise<std_msgs::UInt8>("speed_right", 1);

    ros::Subscriber subscriber_left  = nodeHandle.subscribe("left_ref",1,i2c_msgCallback_left);
    ros::Subscriber subscriber_right = nodeHandle.subscribe("right_ref",1,i2c_msgCallback_right);

    ros::Rate loopRate(7);  // Frequency of repetition in Hz
    ref_left.data  = 0;
    ref_right.data = 0;
//////////////////////////////////////////////////////////////////////////// I2C SETUP
    signal(SIGINT, signal_callback_handler);

    I2CDevice PIC_1;
    I2CDevice PIC_2;

    /* Data to write */
    unsigned char data_write_1[1] = {0};
    ssize_t size_write_1 = sizeof(data_write_1);

    unsigned char data_write_2[1] = {0};
    ssize_t size_write_2 = sizeof(data_write_2);

    /* Data to read */
    unsigned char data_read_1[1] = {0};
    ssize_t size_read_1 = sizeof(data_read_1);
    memset(data_read_1, 0, sizeof(data_read_1)); // Initialize array to 0

    unsigned char data_read_2[1] = {0};
    ssize_t size_read_2 = sizeof(data_read_2);
    memset(data_read_2, 0, sizeof(data_read_2)); // Initialize array to 0
    
    /* Open i2c bus */
    if ((fd = i2c_open("/dev/i2c-0")) == -1) {

        perror("Open i2c bus error");
        return EXIT_FAILURE;

    }

    /* Inirialize device structure */
    init_device(&PIC_1 ,addr_1, fd);
    init_device(&PIC_2 ,addr_2, fd);

    /* IMPLEMENTATION */
    bool was_PIC1_rx_succ = false;
    bool was_PIC1_tx_succ = false;
    bool was_PIC2_rx_succ = false;
    bool was_PIC2_tx_succ = false;
    unsigned int loops_to_analyze = 25;

    while( ros::ok() )
    {    
	ros::spinOnce(); // Checks for received messages

	/* Reception */
	was_PIC1_rx_succ = rx_data(&PIC_1, 0X0, data_read_1, size_read_1); 
	was_PIC2_rx_succ = rx_data(&PIC_2, 0X0, data_read_2, size_read_2);             
	
	/* Transmission */
	was_PIC1_tx_succ = tx_data(&PIC_1, 0X0, data_write_1, size_write_1);
	was_PIC2_tx_succ = tx_data(&PIC_2, 0X0, data_write_2, size_write_2);

	/* Verify transmission */
	verify_data(&PIC_1, was_PIC1_rx_succ, was_PIC1_tx_succ, data_write_1, data_read_1);
	verify_data(&PIC_2, was_PIC2_rx_succ, was_PIC2_tx_succ, data_write_2, data_read_2);

	/* Send data through ROS */
	publisher_left.publish(speed_left);
	publisher_right.publish(speed_right);

	/* Print events in current loop */
	print_data(data_write_1,data_read_1,data_write_2,data_read_2,
		   was_PIC1_tx_succ,was_PIC1_rx_succ,was_PIC2_tx_succ,was_PIC2_rx_succ);

	/* Print analysis of number of errors */	
//	print_num_error(was_PIC1_rx_succ,was_PIC2_rx_succ,was_PIC1_tx_succ,was_PIC2_tx_succ,loops_to_analyze);

	data_write_1[0] = ref_left.data;
	data_write_2[0] = ref_right.data;
	loopRate.sleep();
    }
    return EXIT_SUCCESS;
}



/* ************************** FUNCTIONS ************************** */



/* Fill i2c device struct */
void init_device(I2CDevice* device, unsigned short addr, int fd)
{
    device -> bus  = fd;
    device -> addr = addr;
    device -> tenbit = 0;
    device -> delay  = 25;
    device -> flags  = 0;
    device -> page_bytes  = 2;
    device -> iaddr_bytes = 0; /* Set this to zero, and using i2c_ioctl_xxxx API will ignore chip internal address */
}

/* Verify transmission */
void verify_data(I2CDevice* device, bool was_rx_succ, bool was_tx_succ, unsigned char* data_write, unsigned char* data_read)
{
    //std::cout << CYAN << "Reading from: 0x" << std::hex << device -> addr << std::dec << RESET << std::endl;

    if(device -> addr == addr_1 && was_rx_succ == true)
    {
	speed_left.data = data_read[0];
    }
    else if(device -> addr == addr_2 && was_rx_succ == true)
    {
	speed_right.data = data_read[0];
    }
}

/* Print received data */
void print_data(unsigned char* data_write_1,unsigned char* data_read_1,unsigned char* data_write_2,unsigned char* data_read_2,
		   bool was_PIC1_tx_succ,bool was_PIC1_rx_succ,bool was_PIC2_tx_succ,bool was_PIC2_rx_succ) 
{
    std::cout << "WRITEN = ";
    
    if(was_PIC1_tx_succ == true)
    {
	std::cout << int(data_write_1[0]) << "  ----  ";
    } else {
	std::cout << RED << "ER" << RESET << "  ----  ";
    }
    
    if(was_PIC2_tx_succ == true)
    {
	std::cout << int(data_write_2[0]) << std::endl;
    } else {
	std::cout << RED << "ER" << RESET << std::endl;
    }
    
    std::cout << "READ   = ";

    if(was_PIC1_rx_succ == true)
    {
	std::cout << int(data_read_1[0]) << "  ----  ";
    } else {
	std::cout << RED << "ER" << RESET << "  ----  ";
    }
    
    if(was_PIC2_rx_succ == true)
    {
	std::cout << int(data_read_2[0]) << std::endl;
    } else {
	std::cout << RED << "ER" << RESET << std::endl;
    }
}

/* Prints analisys of errors received */
void print_num_error(bool read_1, bool read_2, bool write_1, bool write_2, unsigned int loops_to_analyze)
{
    if(read_1 == false)
    {
	num_error_read++;
    }
    if(read_2 == false)
    {
	num_error_read++;
    }
    if(write_1 == false)
    {
	num_error_write++;
    }
    if(write_2 == false)
    {
	num_error_write++;
    }

    loop_counter++;
    if(loop_counter == loops_to_analyze)
    {
	current_time = ros::Time::now();
	loop_counter = 0;
	double total_msg = (double)loops_to_analyze * 2.0;
	//double total_msg = (double)loops_to_analyze;
	double incorrect_read_pc = (((double)num_error_read) * 100.0) / total_msg;
	double incorrect_write_pc = (((double)num_error_write) * 100.0) / total_msg;
	std::cout << CYAN <<  "Time = " << (current_time - last_time).toSec() << " -- W ER = " << incorrect_write_pc << " -- R ER = " << incorrect_read_pc << RESET << std::endl;

	last_time = current_time;
	num_error_read  = 0;
	num_error_write = 0;
    }
}

/* Receive data */
bool rx_data(const I2CDevice* device, unsigned int iaddr, void* buf, size_t len)
{
    bool was_succ = true;
    if(i2c_ioctl_read(device, iaddr, buf, len) != len)
    {
        was_succ = false;
    }	
    return was_succ;
}

/* Transmit data */
bool tx_data(const I2CDevice* device, unsigned int iaddr, void* buf, size_t len)
{
    bool was_succ = true;
    if(i2c_ioctl_write(device, iaddr, buf, len) != len)
    {
        was_succ = false;
    }	
    return was_succ;
}

/* Closes bus when CTRL-C */
void signal_callback_handler(int signum) 
{
   std::cout << YELLOW << "\n\nClosing BUS.\n\n" << RESET << std::endl;
   i2c_close(fd);

   // Terminate program
   exit(signum);
}

/* Receive messages from ROS */
void i2c_msgCallback_left(const std_msgs::UInt8& msg) 
{
    ref_left = msg;    
}
void i2c_msgCallback_right(const std_msgs::UInt8& msg) 
{
    ref_right = msg;    
}







//

#include <ros/ros.h>

//ROS Libraries
#include <std_msgs/UInt8.h>
#include <geometry_msgs/Twist.h>

int const MAX_RPM	    = 100;
float const TRACK	    = 0.2;  // This is the distance between the wheels in m
float const WHEEL_RADIUS    = 0.05; // radius of the wheels in m
int const REF_VAL_OFFSET    = 100;  //Used for microcontroller interpretation

class Twist2MotorRef
{
    private:
	std_msgs::UInt8 left_ref_, right_ref_;

	ros::NodeHandle *nh_p_;

	ros::Subscriber vel_sub_;

	ros::Publisher right_rpm_pub_;
	ros::Publisher left_rpm_pub_;

	void velCallback(const geometry_msgs::Twist::ConstPtr &msg);

    public:
	Twist2MotorRef(ros::NodeHandle *nh);
};

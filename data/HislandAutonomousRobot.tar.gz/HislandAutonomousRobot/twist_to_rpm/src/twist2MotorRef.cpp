#include "twist_to_rpm/twist2MotorRef.h"
#include <iostream>
#include <string.h>
#include <cmath>

Twist2MotorRef::Twist2MotorRef(ros::NodeHandle *node_handle)
{
    nh_p_ = node_handle;

    //Subscription setup
    vel_sub_ = nh_p_->subscribe("/cmd_vel", 1, &Twist2MotorRef::velCallback, this);

    //Publication setup
    right_rpm_pub_  = nh_p_->advertise<std_msgs::UInt8>("/right_ref",1);
    left_rpm_pub_   = nh_p_->advertise<std_msgs::UInt8>("/left_ref",1);

    left_ref_.data  = 0;
    right_ref_.data = 0;
}

void Twist2MotorRef::velCallback(const geometry_msgs::Twist::ConstPtr &msg)
{
    float right_ref = 0.0, left_ref = 0.0;
    //Calculate left wheel rpm
    right_ref	= msg->linear.x + (msg->angular.z * TRACK)/2.0;	// linear velocity m/s
    left_ref	= msg->linear.x - (msg->angular.z * TRACK)/2.0;	// linear velocity m/s

    right_ref /= WHEEL_RADIUS;	//angular velocity rad/s
    left_ref /= WHEEL_RADIUS;	//angular velocity rad/s

    right_ref *= 60/(2*M_PI);    //RPM
    left_ref *= 60/(2*M_PI);	    //RPM

    right_ref = right_ref > MAX_RPM ? MAX_RPM : right_ref;
    left_ref = left_ref > MAX_RPM ? MAX_RPM : left_ref;

    /* These conditionals are done so that the microcontroler
     * can interpret the direction of the motors. First,
     * the magnitude of the RPM for each motor is calculated.
     * Then, each RPM reference is offseted. The microntroler
     * interprets a forward direction from a range 101-200
     * inclusive and a backward direction from a range 1-100
     * inclusive. A value of zero will stop the motors.
    */
    if(right_ref < 0)			//If direction is in reverse
	right_ref *= -1;		//make value positive
    else if(right_ref > 0)
	right_ref += REF_VAL_OFFSET;
    
    if(left_ref < 0)			//If direction is in reverse
	left_ref *= -1;			//make value positive
    else if(left_ref > 0)
	left_ref += REF_VAL_OFFSET;

    if(right_ref == 0)
	right_ref = 215;
    if(left_ref == 0)
	left_ref = 215;

    right_ref_.data = int(right_ref);
    left_ref_.data = int(left_ref);
    
    right_rpm_pub_.publish(right_ref_);
    left_rpm_pub_.publish(left_ref_);
}

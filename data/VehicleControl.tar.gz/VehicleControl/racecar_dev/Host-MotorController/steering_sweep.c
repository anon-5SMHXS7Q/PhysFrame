#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>   


int main() {
	char byte;
	int fd = open("/dev/ttyACM1", O_RDWR);
	write(fd, "s", 1);
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
 
 
struct termios initial_settings,
               new_settings;
 
 
 
int main(int argc, char *argv[])
{
  // set up non-blocking keyboard
  int char_in;
  unsigned char key;
  tcgetattr(0,&initial_settings);
  new_settings = initial_settings;
  new_settings.c_lflag &= ~ICANON;
  new_settings.c_lflag &= ~ECHO;
  new_settings.c_lflag &= ~ISIG;
  new_settings.c_cc[VMIN] = 0;
  new_settings.c_cc[VTIME] = 0;
  tcsetattr(0, TCSANOW, &new_settings);
 
  while(1)
  {
	// get character from keyboard input
    char_in = getchar();
 
    if(char_in != EOF)
    {
      key = char_in;
 
      if(key == 27)  /* Escape key pressed */
      {
        break;
      }
 
    /* do something useful here with key */
    printf("key: %d\n", key);
    }
  }
 
  tcsetattr(0, TCSANOW, &initial_settings);
 
  return(0);
}

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>

#include <unistd.h>
#include <fcntl.h>   

// send keyboard input bytes to Arduino
 
struct termios initial_settings,
               new_settings;
 
 
 
int main(int argc, char *argv[])
{
  // set up non-blocking keyboard
  int char_in;
  unsigned char key;
  tcgetattr(0,&initial_settings);
  new_settings = initial_settings;
  new_settings.c_lflag &= ~ICANON;
  new_settings.c_lflag &= ~ECHO;
  new_settings.c_lflag &= ~ISIG;
  new_settings.c_cc[VMIN] = 0;
  new_settings.c_cc[VTIME] = 0;
  tcsetattr(0, TCSANOW, &new_settings);
  
  // set up serial output to Arduino motor controller
  int fd = open("/dev/ttyACM0", O_RDWR);
 
  while(1)
  {
	// get character from keyboard input
    char_in = getchar();
 
    if(char_in != EOF)
    {
      key = char_in;
 
      if(key == 27)  /* Escape key pressed */
      {
        break;
      }
 
    /* do something useful here with key */
    // echo key value to console
    printf("key: %d  pulse: %d\n", key, key*14);
    // send key value to serial output
    write(fd, &key, 1);
    }
  }
 
  tcsetattr(0, TCSANOW, &initial_settings);
 
  return(0);
}

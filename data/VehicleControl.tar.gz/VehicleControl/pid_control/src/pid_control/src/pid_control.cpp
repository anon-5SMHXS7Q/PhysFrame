#include <stdio.h>
#include <stdlib.h>
#include <termios.h>

#include <unistd.h>
#include <fcntl.h>   

#include "ros/ros.h"
#include "std_msgs/Float64.h"
 
struct termios initial_settings,
               new_settings;

//int fd = open("/dev/ttyACM0", O_RDWR); 
int serial_fd;
char steering_angle;

int set_interface_attribs (int fd, int speed, int parity)
{
	struct termios tty;
	memset (&tty, 0, sizeof tty);
	if (tcgetattr (fd, &tty) != 0)
	{
		//error_message ("error %d from tcgetattr", errno);
		printf("Error in tcgetattr\n");
		return -1;
	}
	
	cfsetospeed (&tty, speed);
	cfsetispeed (&tty, speed);
	
	tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
	// disable IGNBRK for mismatched speed tests; otherwise receive break
	// as \000 chars
	tty.c_iflag &= ~IGNBRK;         // disable break processing
	tty.c_lflag = 0;                // no signaling chars, no echo,
									// no canonical processing
	tty.c_oflag = 0;                // no remapping, no delays
	tty.c_cc[VMIN]  = 0;            // read doesn't block
	tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout
	
	tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl
	
	tty.c_cflag |= (CLOCAL | CREAD);// ignore modem controls,
									// enable reading
	tty.c_cflag &= ~(PARENB | PARODD); // shut off parity
	tty.c_cflag |= parity;
	tty.c_cflag &= ~CSTOPB;
	tty.c_cflag &= ~CRTSCTS;
	
	if (tcsetattr (fd, TCSANOW, &tty) != 0)
	{
		//error_message ("error %d from tcsetattr", errno);
		printf("Error in tcsetattr\n");
		return -1;
	}
	return 0;
}

void proportion_to_steering_angle(const std_msgs::Float64::ConstPtr& msg)
{
	// should be used only for demonstrating ros communication
	// TODO: implement full PID control from LIDAR to steering
	
	float proportion = msg->data;
	int intermediate_value = 60 + (proportion * 67);
	
	// value between 0 and 127
	// 60 for full left, 127 for full right
	steering_angle = (char) intermediate_value;
    //write(fd, &steering_angle, 1);
    
    write(serial_fd, &steering_angle, 1);
    printf("Steering Angle: %d\n", steering_angle);
}
 
int main(int argc, char *argv[])
{
	// set up serial output to Arduino motor controller
	
	int fd = open("/dev/ttyACM0", O_RDWR | O_NOCTTY | O_SYNC);
	if (fd < 0)
	{
		printf("Error opening serial port.\n");
		return 1;
	}
	
	set_interface_attribs(fd, B115200, 0);
	serial_fd = fd;
	
	ros::init(argc, argv, "pid_control");
	ros::NodeHandle n;
	
	ros::Subscriber sub = n.subscribe("pcl_lr_proportion", 10, proportion_to_steering_angle);
	
	ros::spin();
	
	//tcsetattr(0, TCSANOW, &initial_settings);
	
	return 0;
}

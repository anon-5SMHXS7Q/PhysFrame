#pragma once

#include <tf2_ros/buffer.h>
#include <memory>

using TFListenerPtr = std::shared_ptr<tf2_ros::Buffer>;

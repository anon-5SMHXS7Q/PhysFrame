Utils to work with DJI Onboard SDK: add tf and odometry publishers based on geodetic conversions as far as gimbal tf.

Dependences: 

If you havent installed velodyne driver: http://wiki.ros.org/velodyne

Launch:

Use roslaunch dji_command coords_bringup.launch


Note: this is a contribution of https://github.com/frontw

# Mini-Lab packages
Please refere to the robot wiki entry in the link below: http://wiki.ros.org/Mini-Lab

Our tutorial pages contain all the needed information to simulate the robot and test all of its features.

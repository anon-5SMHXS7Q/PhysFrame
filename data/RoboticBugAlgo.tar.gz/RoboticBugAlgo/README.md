<h1>RoboticBugAlgo</h1>

<h2>Project</h2>

<b>Kind : </b>Class Project (Master 2 - Pratique Professionnelle)

<b>Subject : </b> Implémentation et Déploiement d’une famille d’algorithmes de Navigation pour les robots

<b>Release : </b> Orcocos Component (C++)

<h2>URL</h2>

<b>Subject URL : </b> <a href="https://github.com/BlackSlashProd/RoboticBugAlgo/blob/master/doc/PP1_ProjetRobotique_CahierDesCharges.pdf" target="_blank">ProjectBugAlgo.pdf</a><br/>
 
<h2>Authors</h2>

<b>Barbier Clément (3061254)</b><br/>

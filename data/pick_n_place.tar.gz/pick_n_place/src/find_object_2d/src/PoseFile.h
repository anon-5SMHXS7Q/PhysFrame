#ifndef POSEFILE_H_
#define POSEFILE_H_

#define POS_X
#define POS_Y
#define POS_Z
#define ORI_X
#define ORI_Y
#define ORI_Z
#define ORI_W



#endif /* POSEFILE_H_ */

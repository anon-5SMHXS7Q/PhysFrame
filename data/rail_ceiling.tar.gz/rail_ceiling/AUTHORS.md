Original Authors
----------------

 * [Russell Toris](https://github.com/rctoris/) (russell.toris@gmail.com)

Contributors
------------

 * [Steven Kordell](spkordell@wpi.edu)

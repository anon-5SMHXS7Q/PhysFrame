ros_canopen
===========

Canopen implementation for ROS.

[![Build Status](https://travis-ci.org/ros-industrial/ros_canopen.svg?branch=kinetic-devel)](https://travis-ci.org/ros-industrial/ros_canopen)

The current develop branch is `kinetic-devel`, it targets ROS `kinetic` and `lunar`.
It should work with ROS `jade`, but this is not supported anymore (EOL).
The released version gets synced over to the distro branch for each release.

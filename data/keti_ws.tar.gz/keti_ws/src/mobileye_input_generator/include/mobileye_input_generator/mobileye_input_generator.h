#ifndef MOBILEYE_INPUT_GENERATOR_H
#define MOBILEYE_INPUT_GENERATOR_H
#include <ros/ros.h>

class MobileyeInputGenerator{

public:
  MobileyeInputGenerator();
  void MainLoop();
};
#endif // MOBILEYE_INPUT_GENERATOR_H

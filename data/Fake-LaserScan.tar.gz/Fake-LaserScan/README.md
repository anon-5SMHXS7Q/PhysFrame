# Fake-LaserScan
### ROS package that publishes LaserScan messages. Also contains a launch file with tf transforms and RViz to visualize the fake LaserScan message. 

References:
1. http://wiki.ros.org/navigation/Tutorials/RobotSetup/Sensors
2. http://answers.ros.org/question/198843/need-explanation-on-sensor_msgslaserscanmsg/ 

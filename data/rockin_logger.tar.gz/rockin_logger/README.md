# rockin_logger

This package contains code and launch files that can be used as examples and templates to implement the logging features required for the RoCKIn benchmarking.
Not all the required topics are logged with this code and you must adapt it for your robot.

More info in README.txt

Enrico Piazza 2015/2016
Luca Iocchi 2015 (iocchi@dis.uniroma1.it)

#Autonomous Buggy Team - CS 491/691 Fall 2016

##Team Members
- Niki Silveria
- Brett Knadle
- Phillip Vong
- Monique Dingle
- Cody Worsnop
- Phoebe Argon

##Dependencies / Running

###Dependencies
- Program tested in Ubuntu 14.04 ROS Indigo
- MAVROS needs to be installed

###Running

#####Making in release mode
```bash
catkin_make -DCMAKE_BUILD_TYPE=Release
```

#####Realsense: 

######Realsense Launch File:
```bash
roslaunch realsense_camera r200_nodelet_default.launch
```

######Script for collision detection
```bash
cd ~/catkin_ws/src
./collision_detection.py
```

#####USB oCam:

######oCam Launch File:
```bash
roslaunch usb_cam usb_cam-test.launch
```

######Find Object Launch File:
```bash
roslaunch find_object_2d find_object_2d_gui.launch
```

######Image Rectify
```bash
ROS_NAMESPACE=usb_cam rosrun image_proc image_proc
```

######Script for finding stop sign
```bash
cd ~/catkin_ws/src
./stopsign_detection.py
```

#####MAVROS

######Launch Mavros APM
```bash
roslaunch mavros apm.launch
```

######Setting the Pixhawk Mode (GUIDED, MANUAL, AUTO..)
```bash
rosrun mavros mavsys mode -c GUIDED
```

######Arming the Pixhawk
```bash
rosrun mavros mavsafety arm
```

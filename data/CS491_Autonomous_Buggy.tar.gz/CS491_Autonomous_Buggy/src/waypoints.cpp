#include <ros/ros.h>
#include <mavros_msgs/WaypointPush.h>
#include <mavros_msgs/CommandCode.h>
int main(int argc, char *argv[])
{
/*
mavros_msgs/Waypoint[] waypoints
---
bool success
uint32 wp_transfered

# see enum MAV_FRAME
uint8 frame
uint8 FRAME_GLOBAL = 0
uint8 FRAME_LOCAL_NED = 1
uint8 FRAME_MISSION = 2
uint8 FRAME_GLOBAL_REL_ALT = 3
uint8 FRAME_LOCAL_ENU = 4

# see enum MAV_CMD and CommandCode.msg
uint16 command
(
# Waypoint related commands
uint16 NAV_WAYPOINT = 16
uint16 NAV_LOITER_UNLIM = 17
uint16 NAV_LOITER_TURNS = 18
uint16 NAV_LOITER_TIME = 19
uint16 NAV_RETURN_TO_LAUNCH = 20
uint16 NAV_LAND = 21
uint16 NAV_TAKEOFF = 22
)

bool is_current
bool autocontinue
# meaning of this params described in enum MAV_CMD
float32 param1
float32 param2
float32 param3
float32 param4
float64 x_lat
float64 y_long
float64 z_alt
*/
    ros::init(argc, argv, "actuator_controls_publisher");
    ros::NodeHandle nh;
    if (ros::ok())
    {

 	std::vector<mavros_msgs::Waypoint> waypoints_vec;
	mavros_msgs::Waypoint waypoint_msg;

	waypoint_msg.frame = mavros_msgs::Waypoint::FRAME_GLOBAL;
	waypoint_msg.command = mavros_msgs::CommandCode::NAV_WAYPOINT;
	waypoint_msg.is_current = true;
	waypoint_msg.autocontinue = true;
	waypoint_msg.x_lat = -30.0;
	waypoint_msg.y_long = 30.0;
	waypoint_msg.z_alt = 0.0;
	waypoints_vec.push_back(waypoint_msg);

	waypoint_msg.frame = mavros_msgs::Waypoint::FRAME_GLOBAL;
	waypoint_msg.command = mavros_msgs::CommandCode::NAV_WAYPOINT;
	waypoint_msg.is_current = false;
	waypoint_msg.autocontinue = true;
	waypoint_msg.x_lat = -60.0;
	waypoint_msg.y_long = 60.0;
	waypoint_msg.z_alt = 0.0;
	waypoints_vec.push_back(waypoint_msg);

	waypoint_msg.frame = mavros_msgs::Waypoint::FRAME_GLOBAL;
	waypoint_msg.command = mavros_msgs::CommandCode::NAV_WAYPOINT;
	waypoint_msg.is_current = false;
	waypoint_msg.autocontinue = true;
	waypoint_msg.x_lat = -90.0;
	waypoint_msg.y_long = 90.0;
	waypoint_msg.z_alt = 0.0;
	waypoints_vec.push_back(waypoint_msg);
        
	mavros_msgs::WaypointPush::Request req;
	req.waypoints = waypoints_vec;
	mavros_msgs::WaypointPush::Response resp;
	
	if (ros::service::exists("/mavros/mission/push",false)){
	  if (ros::service::call("/mavros/mission/push",req,resp)){
	    std::cout<<"Success!"<<std::endl;
	    if (resp.success)
	      std::cout<<"Transferred "<<resp.wp_transfered<<std::endl;
	    else
	      std::cout<<"Failed to transfer"<<std::endl;
	  }
	  else
	    std::cout<<"Fail!"<<std::endl;
	}

        ros::spinOnce();
    }
    return 0;
}

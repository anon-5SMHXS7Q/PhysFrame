#include <ros/ros.h>
//#include <mavros_msgs/ActuatorControl.h>
#include <mavros_msgs/GlobalPositionTarget.h>
int main(int argc, char *argv[])
{
/*std_msgs/Header header

uint8 coordinate_frame
uint8 FRAME_GLOBAL_INT = 5
uint8 FRAME_GLOBAL_REL_ALT = 6
uint8 FRAME_GLOBAL_TERRAIN_ALT = 11

uint16 type_mask
uint16 IGNORE_LATITUDE = 1	# Position ignore flags
uint16 IGNORE_LONGITUDE = 2
uint16 IGNORE_ALTITUDE = 4
uint16 IGNORE_VX = 8	# Velocity vector ignore flags
uint16 IGNORE_VY = 16
uint16 IGNORE_VZ = 32
uint16 IGNORE_AFX = 64	# Acceleration/Force vector ignore flags
uint16 IGNORE_AFY = 128
uint16 IGNORE_AFZ = 256
uint16 FORCE = 512	# Force in af vector flag
uint16 IGNORE_YAW = 1024
uint16 IGNORE_YAW_RATE = 2048

float64 latitude
float64 longitude
float32 altitude	# in meters, AMSL or above terrain
geometry_msgs/Vector3 velocity
geometry_msgs/Vector3 acceleration_or_force
float32 yaw
float32 yaw_rate*/

    ros::init(argc, argv, "actuator_controls_publisher");
    ros::NodeHandle nh;
    ros::Publisher position_control_pub = nh.advertise<mavros_msgs::GlobalPositionTarget>("/mavros/setpoint_raw/global", 1000); //rostopic type : mavros_msgs/GlobalPositionTarget
    ros::Rate loop_rate(10);
    double ros_roll;
    double ros_pitch;
    double ros_yaw;
    double ros_throttle;
    while (ros::ok())
    {
        //mavros_msgs::ActuatorControl actuator_control_msg;
        mavros_msgs::GlobalPositionTarget position_target_msg;
        nh.param<double>("ros_roll", ros_roll, 0.0);
        nh.param<double>("ros_pitch", ros_pitch, 0.0);
        nh.param<double>("ros_yaw", ros_yaw, 0.0);
        nh.param<double>("ros_throttle", ros_throttle, 0.0);
        /*send to control group 0:
        0:roll
        1:pitch
        2:yaw
        3:throttle
        4:flaps
        5:spoilers
        6:airbrakes
        7:landing gear
        see https://pixhawk.ethz.ch/mavlink/#SET_ACTUATOR_CONTROL_TARGET
        and https://pixhawk.org/dev/mixing
        */
        /*actuator_control_msg.header.stamp = ros::Time::now();
        actuator_control_msg.group_mix = 0;
        actuator_control_msg.controls[0] = ros_roll;
        actuator_control_msg.controls[1] = ros_pitch;
        actuator_control_msg.controls[2] = ros_yaw;
        actuator_control_msg.controls[3] = ros_throttle;
        actuator_control_msg.controls[4] = 0.0;
        actuator_control_msg.controls[5] = 0.0;
        actuator_control_msg.controls[6] = 0.0;
        actuator_control_msg.controls[7] = 0.0;
        actuator_controls_pub.publish(actuator_control_msg);*/
        position_target_msg.header.stamp = ros::Time::now();
        //position_target_msg.header.frame_id ;
        position_target_msg.coordinate_frame = mavros_msgs::GlobalPositionTarget::FRAME_GLOBAL_INT;
	position_target_msg.type_mask = (mavros_msgs::GlobalPositionTarget::IGNORE_ALTITUDE|mavros_msgs::GlobalPositionTarget::IGNORE_VX|mavros_msgs::GlobalPositionTarget::IGNORE_VY|mavros_msgs::GlobalPositionTarget::IGNORE_VZ|mavros_msgs::GlobalPositionTarget::IGNORE_AFX|mavros_msgs::GlobalPositionTarget::IGNORE_AFY|mavros_msgs::GlobalPositionTarget::IGNORE_AFZ|mavros_msgs::GlobalPositionTarget::FORCE|mavros_msgs::GlobalPositionTarget::IGNORE_YAW_RATE);
	position_target_msg.latitude = -30.0;
	position_target_msg.longitude = 30.0;
	position_target_msg.altitude = 0.0;
	position_target_msg.velocity.x = 0.0;
	position_target_msg.velocity.y = 0.0;
	position_target_msg.velocity.z = 0.0;
	position_target_msg.acceleration_or_force.x = 0.0;
	position_target_msg.acceleration_or_force.y = 0.0;
	position_target_msg.acceleration_or_force.z = 0.0;
	position_target_msg.yaw = 3.141591265358979;
	position_target_msg.yaw_rate = 0.0;
        position_control_pub.publish(position_target_msg);
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}

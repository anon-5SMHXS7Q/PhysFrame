Kangaroo X2 Driver

A driver for the motion controller Kangaroo X2, used with the motor controller Sabertooth dual.

It accepts measurements in radians / second for the two wheels on the JointTrajectory topic, 
and publishes odometry to the JointState topic.

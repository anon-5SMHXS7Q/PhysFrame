#ifndef CONIO_H
#define CONIO_H
/* empty */

#ifdef __cplusplus
extern "C"
#endif
int _getch(void);
#ifdef __cplusplus
extern "C"
#endif
int _kbhit(void);

#endif

# tangentbug

Simple implementation of Tangent Bug algorithm.

Simulation with ROS and Stage using differential robot.

**TODO** and **FIXME**

* In some situations, algorithm loops forever choosing between two tangents;
* Collision avoidance needs improvement.

